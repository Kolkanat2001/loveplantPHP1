<?php
function debug(array $data): void
{
    echo '<pre>' . print_r($data, 1) . '</pre>';
}

function get_products(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM products");
    return $res->fetchAll();
}

function get_product(int $id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}



function get_reviews(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM love_plant.feedback");
    return $res->fetchAll();
}
function get_reviews_blog(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM love_plant.feedback_blog");
    return $res->fetchAll();
}
function get_review(int $id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM love_plant.feedback WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}


function add_to_cart($row): void
{
    if (isset($_SESSION['cart'][$row['id']])) {
        $_SESSION['cart'][$row['id']]['qty'] += 1;
    } else {
        $_SESSION['cart'][$row['id']] = [
            'id' => $_GET['id'],
            'title' => $row['title'],
            'slug' => $row['slug'],
            'price' => $row['price'],
            'qty' => 1,
            'img' => $row['img'],
        ];
    }
    $_SESSION['cart.qty'] = !empty($_SESSION['cart.qty']) ? ++$_SESSION['cart.qty'] : 1;
    $_SESSION['cart.sum'] = !empty($_SESSION['cart.sum']) ? $_SESSION['cart.sum'] + $row['price'] : $row['price'];
}

function wishlist($row): void
{
    if (isset($_SESSION['wishlist'][$row['id']])) {
        $_SESSION['wishlist'][$row['id']]['qty'] += 1;
    } else {
        $_SESSION['wishlist'][$row['id']] = [
            'id' => $_GET['id'],
            'title' => $row['title'],
            'slug' => $row['slug'],
            'price' => $row['price'],
            'qty' => 1,
            'img' => $row['img'],
        ];
    }
}



