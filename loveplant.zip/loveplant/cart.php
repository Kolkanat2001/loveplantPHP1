<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
require("connect.php");


if (isset($_GET['cart'])) {
    switch ($_GET['cart'] == 'add') {
        case 'add':
            $num = isset($_GET['num']);
            $id = isset($_GET['id'])   ? (int)$_GET['id'] : $num+1;

            $product = get_product($id);

            if (!$product) {
                echo json_encode(['code' => 'error', 'answer' => 'Error product']);
            } else {
                add_to_cart($product);
                ob_start();
                require __DIR__ . '/shop.php';
                $cart = ob_get_clean();
                echo json_encode(['code' => 'ok', 'answer' => $cart]);

            }


            break;
        case 'add1':
            $num = isset($_GET['num']);
            $id = (isset($_GET['id']) && $num) ? (int)$_GET['id'] : 0;

            $product1 = get_product($id);


            if (!$product1) {
                echo json_encode(['code' => 'error', 'answer' => 'Error product']);
            } else {
                add_to_cart1($product1);
                ob_start();
                require __DIR__ . '/shop.php';
                $cart = ob_get_clean();
                echo json_encode(['code' => 'ok', 'answer' => $cart]);

            }

            break;
        case 'show':
            require __DIR__ . '/shop.php';
            break;
        case 'clear':
            if (!empty($_SESSION['cart'])) {
                unset($_SESSION['cart']);
                unset($_SESSION['cart.sum']);
                unset($_SESSION['cart.qty']);
            }
            require __DIR__ . '/shop.php';
            break;

    }
}

if (isset($_GET['wishlist'])) {
    switch ($_GET['wishlist'] == 'add') {
        case 'add':
            $id = isset($_GET['id'])   ? (int)$_GET['id'] :

            $product = get_product($id);

            if (!$product) {
                echo json_encode(['code' => 'error', 'answer' => 'Error product']);
            } else {
                wishlist($product);
                ob_start();
                require __DIR__ . '/wishlist.php';
                $wishlist = ob_get_clean();
                echo json_encode(['code' => 'ok', 'answer' => $wishlist]);

            }


            break;
        case 'show':
            require __DIR__ . '/wishlist.php';
            break;

    }
}
if (isset($_GET["action"])) {
    if ($_GET["action"] == "clear") {
        foreach ($_SESSION['cart'] as $id => $item) {
            if ($item["id"] == $_GET["id"]) {
                unset($_SESSION["cart"]);
                unset($_SESSION['cart.sum']);
                unset($_SESSION['cart.qty']);
                echo '<script>window.location="shop.php"</script>';
            }
        }
    }
}


if(isset($_POST['action']) && $_POST['action'] == 'update-qty')
{
    $sessionItem = $_POST['itemID'];
    $sessionItemQty = $_POST['qty'];
    $productSessionPrice = $_SESSION['cart'][$sessionItem]['total_price'];

    $_SESSION['cart'][$sessionItem]['qty'] = $sessionItemQty;
    $_SESSION['cart'][$sessionItem]['total_price'] = $sessionItemQty * $productSessionPrice;

    echo json_encode(['msg' => 'success']);
    exit();
}

if (isset($_POST['id']) && isset($_POST['number'])) {
    $id = $_POST['id'];
    $num = $_POST['number'];
    $sqlDetailPro = "SELECT * FROM products WHERE id = '$id'";
    $con = mysqli_connect("localhost", "root", "", "catalog");
    $resultDetailPro = mysqli_query($con, $sqlDetailPro) or die(mysqli_error($con));
    $rowProDetail = mysqli_fetch_row($resultDetailPro);
    if (!isset($_SESSION['cart'])) {
        $cart = array(
            $id => array(
                'title' => $rowProDetail['1'],
                'content' => $rowProDetail['3'],
                'price' => $rowProDetail['5'],
                'qty' => $num,
                'img' => $rowProDetail['4']
            )
        );
    } else {
        $cart = $_SESSION['cart'];
        if (array_key_exists($id, $cart)) {
            $cart[$id] = array(
                'title' => $rowProDetail['1'],
                'content' => $rowProDetail['3'],
                'price' => $rowProDetail['5'],
                'qty' => $cart[$id]["qty"] + $num,
                'img' => $rowProDetail['4']

            );
        } else {
            $cart[$id] = array(
                'title' => $rowProDetail['1'],
                'content' => $rowProDetail['3'],
                'price' => $rowProDetail['5'],
                'qty' => $num,
                'img' => $rowProDetail['4']
            );
        }
    }
    $cart = $_SESSION['cart'];
   echo '<prE>';
    print_r($cart);

}


