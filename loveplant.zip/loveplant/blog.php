<?php session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$review = get_reviews();?>
<!DOCTYPE html>
<?php
include("shop/path.php");

include (ROOT_PATH . "/app/controllers/topics.php");
$posts = array();
$postsTitle = 'Recent Posts';

if (isset($_GET['t_id'])) {
    $posts = getPostsByTopicId($_GET['t_id']);
    $postsTitle = "You searched for posts under '" . $_GET['name'] . "'";
} else if (isset($_POST['search-term'])) {
    $postsTitle = "You searched for '" . $_POST['search-term'] . "'";
    $posts = searchPosts($_POST['search-term']);
} else {
    $posts = getPublishedPosts();
}
?>
<!DOCTYPE html>
<html  lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - blog</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Blog</h3>
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li>blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--blog area start-->
<div class="blog_page_section mt-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="blog_wrapper">
                    <?php foreach ($posts as $post): ?>
                        <article class="single_blog">
                            <figure>
                                <div class="blog_thumb">
                                    <a href="blog-details.php?id=<?php echo $post['id']; ?>"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                                </div>
                                <figcaption class="blog_content">
                                    <h4 class="post_title"><a href="blog-details.php?id=<?php echo $post['id']; ?>"><i class="fa fa-paper-plane"></i>
                                            <?php echo $post['title']; ?></a></h4>
                                    <div class="blog_meta">
                                        <p>By <a href="#"><?php echo $post['username']; ?></a> / Date <a href="#"><?php echo date('F j, Y', strtotime($post['created_at'])); ?></a>
                                            / Category: <a>
                                                <?php echo $topic['name']; ?></a>
                                        </p>
                                    </div>
                                    <p class="post_desc"><?php echo html_entity_decode(substr($post['body'], 0, 150) . '...'); ?></p>
                                    <footer class="btn_more">
                                        <a href="blog-details.php?id=<?php echo $post['id']; ?>"> Read more</a>
                                    </footer>
                                </figcaption>
                            </figure>
                        </article>
                    <?php endforeach;?>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <div class="blog_sidebar_widget">
                    <form action="blog.php" method="post">
                    <div class="widget_list widget_search">
                        <div class="widget_title">
                            <h3>Search</h3>
                        </div>
                        <form action="#">
                            <input formmethod="post" placeholder="Search..." name="search-term" type="text">

                        </form>
                    </div>
                    </form>
                    <div class="widget_list comments">
                        <div class="widget_title">
                            <h3>Recent Comments</h3>
                        </div>
                        <?php
                        include ('inc/db.php');

                        $query=$pdo->prepare("select *from love_plant.feedback_blog LIMIT 0,4");
                        $query->execute();

                        while($r=$query->fetch()):?>
                        <div class="post_wrapper">
                            <div class="post_thumb">
                                <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                            </div>
                            <div class="post_info">
                                <span> <a href="#"><?= $r['name']?></a> says:</span>
                                <a href="blog-details.html"><?= $r['comment']?></a>
                            </div>
                        </div>

                        <?php endwhile;?>
                    </div>
                    <div class="widget_list widget_post">
                        <div class="widget_title">
                            <h3>Recent Posts</h3>
                        </div>
                        <?php foreach ($posts as $post): ?>
                        <div class="post_wrapper">
                            <div class="post_thumb">
                                <a href="blog-details.php?id=<?php echo $post['id']; ?>"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                            </div>
                            <div class="post_info">
                                <h4><a href="blog-details.php?id=<?php echo $post['id']; ?>"><?php echo html_entity_decode(substr($post['title'], 0, 20) . '...'); ?></a></h4>
                                <span><?php echo date('F j, Y', strtotime($post['created_at'])); ?> </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="widget_list widget_categories">
                        <div class="widget_title">

                            <h3>Categories</h3>
                        </div>
                        <ul>
                            <?php foreach ($topics as $key => $topic): ?>
                                <li><a href="<?php echo 'blog.php?t_id=' . $topic['id'] ; ?>"><?php echo $topic['name']; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!--blog area end-->

<!--blog pagination area start-->
<div class="blog_pagination">
</div>
<!--blog pagination area end-->

<!--brand area start-->
<div class="brand_area color_five">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->

<!-- JS
============================================ -->
<!--jquery min js-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>