<?php
$connection= mysqli_connect("localhost", "root",'');
 mysqli_select_db($connection, 'love_plant')
?>