<?php
error_reporting (-1);
session_start();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - my account</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>


</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--header area end-->


<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>My Account</h3>
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li>My account</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!-- my account start  -->
<section class="main_content_area">
    <div class="container">
        <div class="account_dashboard">
            <div class="row">
                <div class="col-sm-12 col-md-3 col-lg-3">
                    <!-- Nav tabs -->
                    <div class="dashboard_tab_button">
                        <ul role="tablist" class="nav flex-column dashboard-list">
                            <li> <a href="#orders" data-toggle="tab" class="nav-link">Orders</a></li>
                            <li> <a href="#comments" data-toggle="tab" class="nav-link">Comments</a></li>
                            <li><a href="#address" data-toggle="tab" class="nav-link">Addresses</a></li>
                            <li><a href="#paypal-payments" data-toggle="tab" class="nav-link">Paypal payments</a>
                            </li>
                            <li><a href="./shop/logout.php" class="nav-link">logout</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-9 col-lg-9">
                    <!-- Tab panes -->
                    <div class="tab-content dashboard_content">

                        <div class="tab-pane fade" id="orders">
                            <h3>Orders</h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Order</th>
                                        <th>Date</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <?php
                                        include ('inc/db.php');

                                        $query=$pdo->prepare("select *from love_plant.order_details ");
                                        $query->execute();

                                        while($row=$query->fetch()):
                                        if($row['user_id']==$_SESSION['id']):?>
                                        <td><?= $row['order_id']?></td>
                                        <td><?= $row['created_at']?></td>
                                        <td><?= $row['title']?></td>
                                        <td><span class="success"><?= $row['order_status']?></span></td>
                                        <td><?= $row['total_price']?> for <?= $row['qty']?> item </td>
                                    </tr>
                                    <?php endif;?>
                                    <?php endwhile;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="comments">
                            <h3>Comments</h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Comment</th>
                                        <th>Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <?php
                                        include ('inc/db.php');

                                        $query=$pdo->prepare("select *from love_plant.feedback ");
                                        $query->execute();

                                        while($row=$query->fetch()):
                                        if($row['user_id']==$_SESSION['id']):?>
                                        <td><?= $row['comment']?></td>
                                        <td><?= $row['created_at']?></td>
                                    </tr>
                                    <?php endif;?>
                                    <?php endwhile;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                        <div class="tab-pane" id="address">
                            <p>The following addresses will be used on the checkout page by default.</p>
                            <h4 class="billing-address">Billing address</h4>
                            <?php
                                        include ('inc/db.php');

                                        $query=$pdo->prepare("select *from love_plant.checkout ");
                                        $query->execute();

                                        while($row=$query->fetch()):
                            if($row['user_id']==$_SESSION['id']):   ?>
                            <p><strong><?= $row['first_name']?> <?= $row['last_name']?></strong></p>
                            <address>
                                <span><strong>City:</strong> <?= $row['city']?></span>,
                                <br>
                                <span><strong>Address:</strong> <?= $row['address']?></span>,
                                <br>
                                <span><strong>Address 2:</strong> <?= $row['address2']?></span>,
                                <br>
                                <span><strong>Email:</strong> <?= $row['email']?></span>
                            </address>
                            <?php endif;?>
                            <?php endwhile;?>
                        </div>
                        <div class="tab-pane fade" id="paypal-payments">
                            <h3>Paypal Details</h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>PayerID</th>
                                        <th>PaymentID</th>
                                        <th>Token</th>
                                        <th>Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <?php
                                        include ('inc/db.php');

                                        $query=$pdo->prepare("select *from love_plant.orders ");
                                        $query->execute();

                                        while($row=$query->fetch()):
                                        if($row['user_id']==$_SESSION['id']):?>
                                        <td><?= $row['payerID']?></td>
                                        <td><?= $row['paymentID']?></td>
                                        <td><?= $row['token']?></td>
                                        <td><span class="success">Success</span></td>
                                    </tr>
                                    <?php endif;?>
                                    <?php endwhile;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- my account end   -->

<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include('assets/layouts/footer.php');?>
<!--footer area end-->

<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>




</body>

</html>