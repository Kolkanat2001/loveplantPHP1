<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();

function pre($array){
    echo "<pre>";
    print_r($array);
    echo "</pre>";
}

function validate_input($input){
    $input = stripslashes(trim($input));
    $input = htmlentities($input,ENT_QUOTES);
    return $input;
}

if(isset($_POST['submit']))
{
    if(isset($_POST['first_name'],$_POST['last_name'],$_POST['city'],$_POST['address'], $_POST['phone'], $_POST['email'], $_POST['card_number'], $_POST['expiry_month'], $_POST['expiry_year'], $_POST['cvc']) && !empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['city']) && !empty($_POST['address']) &&  !empty($_POST['phone']) && !empty($_POST['email']) && !empty($_POST['card_number']) && !empty($_POST['expiry_month']) && !empty($_POST['expiry_year'])&& !empty($_POST['cvc']) )
    {
        $firstName = $_POST['first_name'];

        if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
        {
            $errorMsg[] = 'Please enter valid email address';
        }
        else
        {
            //validate_input is a custom function
            //you can find it in helpers.php file
            $firstName  = validate_input($_POST['first_name']);
            $lastName   = validate_input($_POST['last_name']);
            $city       = validate_input($_POST['city']);
            $address    = validate_input($_POST['address']);
            $address2   = (!empty($_POST['address'])?validate_input($_POST['address']):'');

            $phone      = validate_input($_POST['phone']);
            $email      = validate_input($_POST['email']);
            $card_number      = validate_input($_POST['card_number']);
            $expiry_month      = validate_input($_POST['expiry_month']);
            $expiry_year      = validate_input($_POST['expiry_year']);
            $cvc     = validate_input($_POST['cvc']);


            $host = 'localhost';
            $db = 'love_plant';
            $user = 'root';
            $pass = '';
            $charset = 'utf8';

            $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
            $opt = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            $pdo = new PDO($dsn, $user, $pass, $opt);



            $sql = 'insert into love_plant.checkout (first_name, last_name, city, address, address2, phone, email,  order_status,created_at, updated_at, card_number, expiry_month, expiry_year, cvc) values (:fname, :lname, :city,  :address, :address2, :phone,:email,   :order_status,:created_at, :updated_at, :card_number, :expiry_month, :expiry_year, :cvc)';
            $statement = $pdo->prepare($sql);
            $params = [
                'fname' => $firstName,
                'lname' => $lastName,
                'city' => $city,
                'address' => $address,
                'address2' => $address2,
                'phone' => $phone,
                'email' => $email,
                'order_status' => 'confirmed',
                'created_at'=> date('Y-m-d H:i:s'),
                'updated_at'=> date('Y-m-d H:i:s'),
                'card_number' => $card_number,
                'expiry_month' => $expiry_month,
                'expiry_year' => $expiry_year,
                'cvc' => $cvc

            ];

            $statement->execute($params);
            if($statement->rowCount() == 1)
            {

                $getOrderID = $pdo->lastInsertId();

                if(isset($_SESSION['cart']) || !empty($_SESSION['cart']))
                {
                    $sqlDetails = 'insert into love_plant.order_details (order_id,  title, price, qty, total_price,user_id) values(:order_id,:title,:price,:qty,:total_price, :user_id)';
                    $orderDetailStmt = $pdo->prepare($sqlDetails);

                    $totalPrice = 0;
                    foreach($_SESSION['cart'] as $item)
                    {
                        $total=$item['price']*$item['qty'];
                        $totalPrice+=$total;

                        $paramOrderDetails = [
                            'order_id' =>  $getOrderID,
                            'title' =>  $item['title'],
                            'price' =>  $item['price'],
                            'qty' =>  $item['qty'],
                            'total_price' =>  $totalPrice,
                            'user_id' =>  $_SESSION['id']
                        ];

                        $orderDetailStmt->execute( $paramOrderDetails);
                    }

                    $updateSql = 'update love_plant.checkout set total_price = :total where id = :id';

                    $rs = $pdo->prepare($updateSql);
                    $prepareUpdate = [
                        'total' => $totalPrice,
                        'id' =>$getOrderID
                    ];

                    $rs->execute($prepareUpdate);

                    unset($_SESSION['cart']);
                    $_SESSION['confirm_order'] = true;
                    echo '<script>window.location="thank-you.php"</script>';
                    exit();
                }
            }
            else
            {
                $errorMsg[] = 'Unable to save your order. Please try again';
            }
        }
    }
    else
    {
        $errorMsg = [];

        if(!isset($_POST['first_name']) || empty($_POST['first_name']))
        {
            $errorMsg[] = 'First name is required';
        }
        else
        {
            $fnameValue = $_POST['first_name'];
        }

        if(!isset($_POST['last_name']) || empty($_POST['last_name']))
        {
            $errorMsg[] = 'Last name is required';
        }
        else
        {
            $lnameValue = $_POST['last_name'];
        }

        if(!isset($_POST['city']) || empty($_POST['city']))
        {
            $errorMsg[] = 'City is required';
        }
        else
        {
            $cityValue = $_POST['city'];
        }

        if(!isset($_POST['phone']) || empty($_POST['phone']))
        {
            $errorMsg[] = 'Phone is required';
        }
        else
        {
            $phoneValue = $_POST['phone'];
        }
        if(!isset($_POST['email']) || empty($_POST['email']))
        {
            $errorMsg[] = 'Email is required';
        }
        else
        {
            $emailValue = $_POST['email'];
        }

        if(!isset($_POST['address']) || empty($_POST['address']))
        {
            $errorMsg[] = 'Address is required';
        }
        else
        {
            $addressValue = $_POST['address'];
        }




        if(isset($_POST['address2']) || !empty($_POST['address2']))
        {
            $address2Value = $_POST['address2'];
        }

    }
}
?>

<?php
require 'paypal/config.php';

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>Love & Plant - checkout page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="/assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="/assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="/assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="/assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="/assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="/assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="/assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="/assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!--modernizr min js here-->
    <script src="/assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Checkout</h3>
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li>Checkout</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--Checkout page section-->
<div class="Checkout_section  mt-100" id="accordion">
    <div class="container">
        <div class="row">

        </div>
        <div class="checkout_form">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <form  method="post">
                        <h3>Billing Details</h3>
                        <?php
                        if(isset($errorMsg) && count($errorMsg) > 0)
                        {
                            foreach($errorMsg as $error)
                            {
                                echo '<div class="alert alert-danger">'.$error.'</div>';
                            }
                        }
                        ?>
                        <div class="row">
                            <div class="col-lg-6 mb-20">
                                <label>First Name <span>*</span></label>
                                <input formmethod="post" type="text" id="firstName" name="first_name" class="form-control" placeholder="" value="<?= $_SESSION['username']?>"  class="form-control"  value="<?php echo (isset($fnameValue) && !empty($fnameValue)) ? $fnameValue:'' ?>" >
                            </div>
                            <div class="col-lg-6 mb-20">
                                <label>Last Name <span>*</span></label>
                                <input formmethod="post" type="text" id="lastName" name="last_name" class="form-control" placeholder=""  class="form-control" value="<?php echo (isset($lnameValue) && !empty($lnameValue)) ? $lnameValue:'' ?>"  >
                            </div>

                            <div class="col-12 mb-20">
                                <label for="country">City <span>*</span></label>
                                <input formmethod="post" type="text" id="city" name="city" class="form-control" placeholder=""  class="form-control" value="<?php echo (isset($cityValue) && !empty($cityValue)) ? $cityValue:'' ?>"  >
                            </div>

                            <div class="col-12 mb-20">
                                <label>Address <span>*</span></label>
                                <input formmethod="post" type="text" id="address" name="address" placeholder="" type="text"  class="form-control" value="<?php echo (isset($addressValue) && !empty($addressValue)) ? $addressValue:'' ?>" >
                            </div>
                            <div class="col-12 mb-20">
                                <label>Address 2</label>
                                <input formmethod="post" type="text" id="address2" name="address2" class="form-control" placeholder=""  class="form-control" value="<?php echo (isset($address2Value) && !empty($address2Value)) ? $address2Value:'' ?>" >
                            </div>
                            <div class="col-lg-6 mb-20">
                                <label>Phone<span>*</span></label>
                                <input formmethod="post" type="text" id="phone" name="phone" placeholder="+7(***)****"  class="form-control" <?php echo (isset($phoneValue) && !empty($phoneValue)) ? $phoneValue:'' ?>" >
                            </div>
                            <div class="col-lg-6 mb-20">
                                <label> Email Address <span>*</span></label>
                                <input formmethod="post" type="text" id="email" name="email" class="form-control" <?php echo (isset($emailValue) && !empty($emailValue)) ? $emailValue:'' ?>" >
                            </div>
                            <h3>Payment Details</h3>
                            <div class="col-12 mb-20">
                                <label >Cart Number <span>*</span></label>
                                <input formmethod="post" type="text" id="card_number" name="card_number" class="form-control" placeholder="1234 5678 9012 3456"  class="form-control" value="<?php echo (isset($cityValue) && !empty($cityValue)) ? $cityValue:'' ?>"  >
                            </div>
                            <div class="col-lg-4 mb-20">
                                <label>Expiry Month<span>*</span></label>
                                <input formmethod="post" type="text" id="expiry_month" name="expiry_month" placeholder="MM"  class="form-control" <?php echo (isset($phoneValue) && !empty($phoneValue)) ? $phoneValue:'' ?>" >
                            </div>
                            <div class="col-lg-4 mb-20">
                                <label>Expiry Year<span>*</span></label>
                                <input formmethod="post" type="text" id="expiry_year" name="expiry_year" placeholder="YYYY"  class="form-control" <?php echo (isset($phoneValue) && !empty($phoneValue)) ? $phoneValue:'' ?>" >
                            </div>
                            <div class="col-lg-4 mb-20">
                                <label>CVC<span>*</span></label>
                                <input formmethod="post" type="text" id="cvc" name="cvc" placeholder="123"  class="form-control" <?php echo (isset($phoneValue) && !empty($phoneValue)) ? $phoneValue:'' ?>" >
                            </div>


                            <p> <button class="btn btn-primary btn-lg btn-block" formmethod="post" type="submit" name="submit" value="submit">Continue to checkout</button></p>

                        </div>
                    </form>
                </div>
                <div class="col-lg-6 col-md-6">
                    <form action="#">
                        <h3>Your order</h3>
                        <div class="order_table table-responsive">
                            <table>
                                <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $total=0;
                                $totalPrice =0;
                                $totalPriceUSD =0;
                                $productsID=0;
                                foreach ($_SESSION['cart'] as $id => $item):
                                    $delivery =$item['price']*0.1;
                                    $total=$item['price']*$item['qty'];
                                    $totalPrice+=$total;
                                    $totalPriceUSD=$totalPrice*0.0023;
                                    $productsID=$item['id'];?>
                                    <tr>
                                        <td id="<?php echo $item['product_id'];?>"><?= $item['title'] ?><strong> × <?= $item['qty'] ?></strong></td>
                                        <td><?= $item['price'] * $item['qty'] ?>₸</td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Cart Subtotal</th>
                                    <td><?= $totalPrice ?>₸</td>
                                </tr>
                                <tr>
                                    <th>Delivery</th>
                                    <td><strong><?= $delivery ?>₸</strong></td>
                                </tr>
                                <tr class="order_total">
                                    <th>Order Total</th>
                                    <td><strong><?= $totalPrice + $delivery ;  ?>₸</strong></td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                        <div class="payment_method">
                            <div class="panel-default">
                                <input id="payment" name="check_method" type="radio"
                                       data-target="createp_account" />
                                <label for="payment" data-toggle="collapse" data-target="#method"
                                       aria-controls="method">Create an account?</label>

                                <div id="method" class="collapse one" data-parent="#accordion">
                                    <div class="card-body1">
                                        <p>Please send a check to Store Name, Store Street, Store Town, Store State
                                            / County, Store Postcode.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-default">
                                <input id="payment_defult" name="check_method" type="radio"
                                       data-target="createp_account" />
                                <label for="payment_defult" data-toggle="collapse" data-target="#collapsedefult"
                                       aria-controls="collapsedefult">PayPal <img src="/assets/img/icon/papyel.png"
                                                                                  alt=""></label>

                                <div id="collapsedefult" class="collapse one" data-parent="#accordion">
                                    <div class="card-body1">
                                        <p>Pay via PayPal; you can pay with your credit card if you don’t have a
                                            PayPal account.</p>
                                    </div>
                                </div>
                            </div>
                            <div id="paypal-button-container"></div>
                            <div id="paypal-button"></div>
                            <script src="https://www.paypalobjects.com/api/checkout.js"></script>


                            <script>
                                paypal.Button.render({
                                    style: {
                                        label: 'paypal',
                                        size:  'medium',    // small | medium | large | responsive
                                        shape: 'rect',     // pill | rect
                                        color: 'blue',     // gold | blue | silver | black
                                        tagline: false
                                    },
                                    env: '<?php echo PayPalENV; ?>',
                                    client: {
                                        <?php if(ProPayPal) { ?>
                                        production: '<?php echo PayPalClientId; ?>'
                                        <?php } else { ?>
                                        sandbox: '<?php echo PayPalClientId; ?>'
                                        <?php } ?>
                                    },
                                    payment: function (data, actions) {
                                        return actions.payment.create({
                                            transactions: [{
                                                amount: {
                                                    total: '<?php echo number_format($totalPriceUSD);?>',
                                                    currency: 'USD'
                                                }
                                            }]
                                        });
                                    },
                                    onAuthorize: function (data, actions) {
                                        return actions.payment.execute()
                                            .then(function () {
                                                window.location = "orderDetails.php?paymentID="+data.paymentID+"&payerID="+data.payerID+"&token="+data.paymentToken+"&pid=<?php echo $productsID; ?>";

                                            });
                                    }
                                }, '#paypal-button');
                            </script>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Checkout page section end-->

<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="/assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<script src="/assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="/assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="/assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="/assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="/assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="/assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="/assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="/assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="/assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="/assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="/assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="/assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="/assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="/assets/js/main.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>





</body>

</html>
