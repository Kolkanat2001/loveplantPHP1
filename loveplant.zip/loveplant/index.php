<?php
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';

$products = get_products();

include("shop/path.php");

include (ROOT_PATH . "/app/controllers/topics.php");
$posts = array();
$postsTitle = 'Recent Posts';

if (isset($_GET['t_id'])) {
    $posts = getPostsByTopicId($_GET['t_id']);
    $postsTitle = "You searched for posts under '" . $_GET['name'] . "'";
}
 else {
    $posts = getPublishedPosts();
}
?>
<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>Love & Plant  </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
</head>

<body>

<?php include('assets/layouts/header.php');?>
<!--header area end-->
<?php include("./shop/path.php"); ?>
<!--slider area start-->
<section class="slider_section">
    <div class="slider_area owl-carousel">
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider1.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <h1>BIG SALE</h1>
                            <p>Discount <span>20% Off </span> For Love & Plant Members </p>
                            <a class="button" href="shop.php">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider2.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <h1>Unique design</h1>
                            <p>We decorate <span>your premises </span> with our plants </p>
                            <a class="button" href="index-3.html">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider3.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <h1>Lovely Plants </h1>
                            <p>Call our service <span>we'll take care of </span> your plants </p>
                            <a class="button" href="shop.php">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--slider area end-->

<!--shipping area start-->
<div class="shipping_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="single_shipping">
                    <div class="shipping_icone">
                        <img src="assets/img/about/shipping1.png" alt="">
                    </div>
                    <div class="shipping_content">
                        <h3>Free Delivery</h3>
                        <p>Free shipping around the world for all <br> orders over $120</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single_shipping col_2">
                    <div class="shipping_icone">
                        <img src="assets/img/about/shipping2.png" alt="">
                    </div>
                    <div class="shipping_content">
                        <h3>Safe Payment</h3>
                        <p>With our payment gateway, don’t worry <br> about your information</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single_shipping col_3">
                    <div class="shipping_icone">
                        <img src="assets/img/about/shipping3.png" alt="">
                    </div>
                    <div class="shipping_content">
                        <h3>Friendly Services</h3>
                        <p>You have 30-day return guarantee for <br> every single order</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--shipping area end-->

<!--banner area start-->
<div class="banner_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <figure class="single_banner">
                    <div class="banner_thumb">
                        <a href="shop-fullwidth.html"><img src="assets/img/bg/banner1.jpg" alt=""></a>
                        <div class="banner_content">
                            <h3>Big Sale Products</h3>
                            <h2>Plants <br> For Interior</h2>
                            <a href="shop-fullwidth.html">Shop Now</a>
                        </div>
                    </div>
                </figure>
            </div>
            <div class="col-lg-6 col-md-6">
                <figure class="single_banner">
                    <div class="banner_thumb">
                        <a href="shop-fullwidth.html"><img src="assets/img/bg/banner2.jpg" alt=""></a>
                        <div class="banner_content">
                            <h3>Top Products</h3>
                            <h2>Plants <br> For Healthy</h2>
                            <a href="shop-fullwidth.html">Shop Now</a>
                        </div>
                    </div>
                </figure>
            </div>
        </div>
    </div>
</div>
<!--banner area end-->

<!--product area start-->
<div class="product_area  mb-95">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product_header">
                    <div class="section_title">
                        <h2>Our Products</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-content">

                <div class="row">
                    <div class="product_carousel product_column4 owl-carousel">
<?php
include ('inc/db.php');

$query=$pdo->prepare("select *from love_plant.products LIMIT 0,12");
$query->execute();

while($row=$query->fetch()):?>
                        <div class="col-lg-3">
                            <div class="product_items">
                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="product-details.php?page=detail&id=<?= $row['id']?>"><img
                                                        src="assets/img/product/<?php echo $row['img'] ;?>" alt=""></a>
                                            <div class="label_product">
                                                <span class="label_sale">-7%</span>
                                            </div>

                                        </div>
                                        <figcaption class="product_content">
                                            <div class="product_rating">
                                                <ul>
                                                    <li><a href="#"><i class="icon-star"></i></a></li>
                                                    <li><a href="#"><i class="icon-star"></i></a></li>
                                                    <li><a href="#"><i class="icon-star"></i></a></li>
                                                    <li><a href="#"><i class="icon-star"></i></a></li>
                                                    <li><a href="#"><i class="icon-star"></i></a></li>
                                                </ul>
                                            </div>
                                            <h4 class="product_name"><a href="product-details.php?page=detail&id=<?= $row['id']?>"><?php echo $row['title'];?></a></h4>
                                            <div class="price_box">
                                                <span class="current_price"><?php echo $row['price'];?>₸</span>
                                                <span class="old_price"><?php echo $row['old_price'];?>₸</span>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                        </div>
<?php endwhile;?>
                    </div>

            </div>
        </div>
    </div>
</div>
<!--product area end-->

<!--product area start-->
<div class="product_area product_deals ">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Today Deals</h2>
                </div>
            </div>
        </div>
        <div class="product_deals_container">
            <div class="row">
                <div class="product_carousel product_column5 owl-carousel">
                    <?php
                    include ('inc/db.php');

                    $query=$pdo->prepare("select *from love_plant.products LIMIT 6,12");
                    $query->execute();

                    while($row=$query->fetch()):?>
                    <div class="col-lg-3">
                        <article class="single_product">
                            <figure>
                                <div class="product_thumb">
                                    <a class="primary_img" href="product-details.php?page=detail&id=<?= $row['id']?>"><img
                                                src="assets/img/product/<?= $row['img']?>" alt=""></a>
                                    <div class="label_product">
                                        <span class="label_sale">-7%</span>
                                    </div>
                                    <div class="product_timing">
                                        <div data-countdown="2022/06/09"></div>
                                    </div>
                                </div>
                                <figcaption class="product_content">
                                    <div class="product_rating">
                                        <ul>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                        </ul>
                                    </div>
                                    <h4 class="product_name"><a href="product-details.php?page=detail&id=<?= $row['id']?>"><?= $row['title']?></a>
                                    </h4>
                                    <div class="price_box">
                                        <span class="current_price"><?= $row['price']?>₸</span>
                                        <span class="old_price"><?= $row['old_price']?>₸</span>
                                    </div>
                                </figcaption>
                            </figure>
                        </article>
                    </div>
                    <?php endwhile;?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--product area end-->

<!--testimonial area start-->
<div class="testimonial_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>What Our Customers Says ?</h2>
                </div>
            </div>
        </div>
        <div class="testimonial_container">
            <div class="row">
                <div class="testimonial_carousel owl-carousel">
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ When a beautiful design is combined with powerful technology, <br>
                                    it truly is an artwork. I love how my website operates and looks with this
                                    theme. Thank you for the awesome product. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/customer.png" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Rebecka Filson</a> / <span>CEO of CSC</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ When a beautiful design is combined with powerful technology, <br>
                                    it truly is an artwork. I love how my website operates and looks with this
                                    theme. Thank you for the awesome product. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/testimonial2.png" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Amber Laha</a> / <span>CEO of DND</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ When a beautiful design is combined with powerful technology, <br>
                                    it truly is an artwork. I love how my website operates and looks with this
                                    theme. Thank you for the awesome product. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/testimonial3.png" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Lindsy Neloms</a> / <span>CEO of SFD</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--testimonial area end-->

<!--blog area start-->
<section class="blog_section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Our Latest Posts</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="blog_carousel blog_column3 owl-carousel">
                <?php foreach ($posts as $post): ?>
                <div class="col-lg-3">
                    <article class="single_blog">
                        <figure>
                            <div class="blog_thumb">
                                <a href="blog-details.php?id=<?php echo $post['id']; ?>"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                            </div>
                            <figcaption class="blog_content">
                                <h4 class="post_title"><a href="blog-details.php?id=<?php echo $post['id']; ?>"><?php echo $post['title']; ?></a></h4>
                                <div class="articles_date">
                                    <p>By <span><?php echo $post['username']; ?> / <?php echo date('F j, Y', strtotime($post['created_at'])); ?></span></p>
                                </div>
                                <p class="post_desc"><?php echo html_entity_decode(substr($post['body'], 0, 150) . '...'); ?></p>
                                <footer class="blog_footer">
                                    <a href="blog-details.php?id=<?php echo $post['id']; ?>">Continue Reading</a>

                                </footer>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <?php endforeach;?>
            </div>
        </div>
    </div>
</section>
<!--blog area end-->

<!--newsletter area start-->
<div class="newsletter_area_start">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Get <span>20% Off</span> Your Next Order</h2>
                </div>
                <div class="newsletter_container">
                    <div class="subscribe_form">
                        <form id="mc-form" class="mc-form footer-newsletter">
                            <input id="mc-email" type="email" autocomplete="off" placeholder="Enter you email" />
                            <button id="mc-submit">Subscribe</button>
                            <div class="email_icon">
                                <i class="icon-mail"></i>
                            </div>
                        </form>
                        <!-- mailchimp-alerts Start -->
                        <div class="mailchimp-alerts text-centre">
                            <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                            <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                            <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                        </div><!-- mailchimp-alerts end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--newsletter area end-->

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->


<!--news letter popup start-->
<div class="newletter-popup">
    <div id="boxes" class="newletter-container">
        <div id="dialog" class="window">
            <div id="popup2">
                <span class="b-close"><span>close</span></span>
            </div>
            <div class="box">
                <div class="newletter-title">
                    <h2>Newsletter</h2>
                </div>
                <div class="box-content newleter-content">
                    <label class="newletter-label">Enter your email address to subscribe our notification of our new
                        post &amp; features by email.</label>
                    <div id="frm_subscribe">
                        <form name="subscribe" id="subscribe_popup">
                            <!-- <span class="required">*</span><span>Enter you email address here...</span>-->
                            <input type="text" value="" name="subscribe_pemail" id="subscribe_pemail"
                                   placeholder="Enter you email address here...">
                            <input type="hidden" value="" name="subscribe_pname" id="subscribe_pname">
                            <div id="notification"></div>
                            <a class="theme-btn-outlined"
                               onclick="email_subscribepopup()"><span>Subscribe</span></a>
                        </form>
                        <div class="subscribe-bottom">
                            <input type="checkbox" id="newsletter_popup_dont_show_again">
                            <label for="newsletter_popup_dont_show_again">Don't show this popup again</label>
                        </div>
                    </div>
                    <!-- /#frm_subscribe -->
                </div>
                <!-- /.box-content -->
            </div>
        </div>

    </div>
    <!-- /.box -->
</div>
<!--news letter popup start-->


<?php include ('assets/layouts/js.php');?>
</body>

</html>