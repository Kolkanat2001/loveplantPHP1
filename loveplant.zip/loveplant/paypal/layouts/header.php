<header>
    <div class="main_header">
        <div class="header_top">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-7">
                        <div class="welcome-text">
                            <p>Free Delivery: Take advantage of our time to save event</p>
                        </div>
                    </div>

                    <div class="col-lg-5 col-md-5">
                        <div class="language_currency text-right">
                            <ul>
                                <li class="currency"><a href="#"> KZT <i class="fa fa-angle-down"></i></a>
                                    <ul class="dropdown_currency">
                                        <li><a href="#">EUR</a></li>
                                        <li><a href="#">USD</a></li>
                                        <li><a href="#">RUP</a></li>
                                    </ul>
                                </li>
                                <li class="language"><a href="#"> English <i class="fa fa-angle-down"></i></a>
                                    <ul class="dropdown_language">
                                        <li><a href="#">French</a></li>
                                        <li><a href="#">Spanish</a></li>
                                        <li><a href="#">Russian</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header_middle">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 col-4">
                        <div class="logo">
                            <a href="index.html"><img src="assets/img/logo/logolove.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-6 col-6">
                        <div class="header_right_info">
                            <div class="search_container">
                                <form action="#">
                                    <div class="hover_category">
                                        <select class="select_option" name="select" id="categori1">
                                            <option selected value="1">All Categories</option>
                                            <option value="2">Plant</option>
                                            <option value="3">Decor</option>
                                            <option value="4">Services</option>
                                        </select>
                                    </div>
                                    <div class="search_box">
                                        <input placeholder="Search product..." type="text">
                                        <button type="submit"><i class="icon-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="header_account_area">
                                <div class="header_account-list top_links">
                                    <a href="#"><i class="icon-users"></i></a>
                                    <ul class="dropdown_links">
                                        <?php if (isset($_SESSION['id'])): ?>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-user"></i>
                                                    <?php echo $_SESSION['username']; ?>
                                                    <i class="" style="font-size: .8em;"></i>
                                                </a>
                                                <ul>
                                                    <?php if($_SESSION['admin']): ?>
                                                        <li><a href="./shop/admin/dashboard.php">Dashboard</a></li>
                                                    <?php endif; ?>
                                                    <li><a href="./logout.php" class="logout">Logout</a></li>
                                                </ul>
                                            </li>
                                        <?php else: ?>
                                            <li><a href="./shop/register.php ">Sign Up</a></li>
                                            <li><a href="./shop/login.php ">Login</a></li>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                                <div class="header_account-list header_wishlist">
                                    <a href="wishlist.php"><i class="icon-heart"></i></a>
                                </div>
                                <div class="header_account-list  mini_cart_wrapper"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <a href="javascript:void(0)" id="get-cart" data-toggle="modal"  data-target="#mini-cart" ><i class="icon-shopping-bag"></i><span class="mini-cart-qty item_count" ><?=(isset($_SESSION['cart']) && count($_SESSION['cart'])) > 0 ? count($_SESSION['cart']):'' ?></span></a>
                                    <!--mini cart-->

                                    <div class="mini_cart" >
                                        <div class="cart_gallery">
                                            <div class="cart_close">
                                                <div class="cart_text" >
                                                    <h3 id="exampleModalLabel">cart</h3>
                                                </div>
                                                <div class="mini_cart_close">
                                                    <a href="javascript:void(0)"><i class="icon-x"></i></a>
                                                </div>
                                            </div>

                                            <div class="modal-cart-content">
                                                <?php if (!empty($_SESSION['cart'])): ?>
                                                    <?php $totalCounter = 0;
                                                    $itemCounter = 0;
                                                    foreach ($_SESSION['cart'] as $id => $item):

                                                        $total = $item['price'] * $item['qty'];
                                                        $totalCounter+= $total;
                                                        $itemCounter+=$item['qty']; ?>
                                                        <div class="cart_item">
                                                            <div class="cart_img">
                                                                <a href="#"><img src="assets/img/product/<?= $item['img'] ?>"
                                                                                 alt="<?= $item['title'] ?>"></a>
                                                            </div>

                                                            <div class="cart_info">
                                                                <a href="#"><?= $item['title'] ?></a>
                                                                <p><?= $item['qty'] ?> x <span> <?= $item['price'] ?> </span></p>
                                                            </div>

                                                            <div class="cart_remove">
                                                                <a href="shop.php?action=delete&id=<?= $item["id"]; ?>"><i class="icon-x"></i></a>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>


                                                    <div class="mini_cart_table">
                                                        <div class="cart_table_border">
                                                            <div class="cart_total">
                                                                <span>Product:</span>
                                                                <span class="price" id="modal-cart-qty"><?php echo ($itemCounter==0)?$itemCounter.' item':$itemCounter.' ';?></span>
                                                            </div>
                                                            <div class="cart_total mt-10">
                                                                <span>Sum:</span>
                                                                <span class="price"><?=$totalCounter ?></span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="mini_cart_footer">
                                                        <div class="cart_button">
                                                            <div class="cart_button">
                                                                <a href="carts.php"><i class="fa fa-shopping-cart"></i> View cart</a>
                                                                <?php if(!empty($_SESSION['cart'])): ?>
                                                            </div>
                                                            <a class="active" href="checkout.php"><i class="fa fa-sign-in"></i>
                                                                Checkout</a>
                                                        </div>
                                                        <div class="cart_button" >
                                                            <a href="cart.php?action=clear&id=<?= $item["id"]; ?>">Clear</a>
                                                        </div>
                                                        <?php endif;?>

                                                    </div>

                                                <?php else:?>
                                                    <p>Carts is empty...</p>
                                                <?php endif;?>




                                            </div>
                                        </div>
                                    </div>
                                    <!--mini cart end-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header_bottom sticky-header">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3">
                        <div class="categories_menu">
                            <div class="categories_title">
                                <h2 class="categori_toggle">Categories</h2>
                            </div>
                            <div class="categories_menu_toggle">
                                <ul>
                                    <li class="menu_item_children"><a href="#">Plants <i
                                                class="fa fa-angle-right"></i></a>
                                        <ul class="categories_mega_menu">
                                            <li class="menu_item_children"><a href="#">Plant</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">home</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu_item_children"><a href="#">Decor</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Interior</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu_item_children"><a href="#">Services</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Service</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu_item_children"><a href="#"> Decor <i
                                                class="fa fa-angle-right"></i></a>
                                        <ul class="categories_mega_menu column_3">
                                            <li class="menu_item_children"><a href="#">Interior</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Interior</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu_item_children"><a href="#">Plant</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Plant</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu_item_children"><a href="#">Services</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Services</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="menu_item_children"><a href="#"> Services <i
                                                class="fa fa-angle-right"></i></a>
                                        <ul class="categories_mega_menu column_2">
                                            <li class="menu_item_children"><a href="#">Services</a>
                                                <ul class="categorie_sub_menu">
                                                    <li><a href="">Services</a></li>
                                                </ul>
                                            </li>

                                        </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <!--main menu start-->
                        <div class="main_menu menu_position">
                            <nav>
                                <ul>
                                    <li><a href="index.php">home<i class="fa fa-angle-down"></i></a>
                                        <ul class="sub_menu">
                                            <li><a href="index.html">Love & Plant Home Page</a></li>

                                            <li><a href="index-3.html">Love & Plant Decoration</a></li>
                                            <li><a href="services.html">Love & Plant Services</a></li>

                                        </ul>
                                    </li>
                                    <li ><a class="" href="shop.php">shop</a>

                                    </li>
                                    <li><a href="blog.php">blog<i class="fa fa-angle-down"></i></a>
                                        <ul class="sub_menu pages">
                                            <li><a href="blog-details.php">blog details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">pages <i class="fa fa-angle-down"></i></a>
                                        <ul class="sub_menu pages">
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="services.html">services</a></li>
                                            <li><a href="contact.php">contact</a></li>
                                            <li><a href="shop/login.php">login</a></li>
                                            <li><a href="shop/register.php">Register</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact.php"> Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                        <!--main menu end-->
                    </div>
                    <div class="col-lg-3">
                        <div class="call-support">
                            <p>Call Support: <a href="tel:87472454517">87472454517</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>