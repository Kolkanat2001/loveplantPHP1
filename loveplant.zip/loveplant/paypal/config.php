<?php
define('ProPayPal', 0);
if(ProPayPal){
    define("PayPalClientId", "*********************");
    define("PayPalSecret", "*********************");
    define("PayPalBaseUrl", "https://api.paypal.com/v1/");
    define("PayPalENV", "production");
} else {
    define("PayPalClientId", "AdoDenCkoyzmnnUOC139zuYtVVhd8LqMgitarqfQ6maV2sB6WPvyMRcVB5ALnzeHYkdU7lG0eGI2EoA1");
    define("PayPalSecret", "EIpXczLP--ns8ElhNkQYMUZ4FGSWyfhXtUhlJsVN6klH-Ac7GxRSM_ihfGoLMFo-mIhDLELfneWEoadr");
    define("PayPal_BASE_URL", "https://api.sandbox.paypal.com/v1/");
    define("PayPalENV", "sandbox");
}
?>