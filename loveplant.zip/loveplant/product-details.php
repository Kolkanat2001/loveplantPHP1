<?php
error_reporting (-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();
$review = get_reviews();


if(isset($_POST['add_to_cart']) && $_POST['add_to_cart'] == 'add to cart')
{
    $productID = intval($_POST['id']);
    $productQty = intval($_POST['product_qty']);

    $sql = "SELECT p.* from products p  WHERE p.id = :productID ";

    $host = 'localhost';
    $db = 'catalog';
    $user = 'root';
    $pass = '';
    $charset = 'utf8';
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $opt = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    $pdo = new PDO($dsn, $user, $pass, $opt);
    $prepare = $pdo->prepare($sql);

    $params = [
        ':productID' =>$productID,
    ];

    $prepare->execute($params);
    $fetchProduct = $prepare->fetch(PDO::FETCH_ASSOC);

    $calculateTotalPrice = number_format($productQty * $fetchProduct['price']);

    $cartArray = [
        'id' =>$productID,
        'qty' => $productQty,
        'title' =>$fetchProduct['title'],
        'price' => $fetchProduct['price'],
        'old_price' => $fetchProduct['old_price'],
        'img' =>$fetchProduct['img'],
        'total_price' => $calculateTotalPrice

    ];

    if(isset($_SESSION['cart']) && !empty($_SESSION['cart']))
    {
        $productIDs = [];
        foreach($_SESSION['cart'] as $cartKey => $cartItem)
        {
            $productIDs[] = $cartItem['id'];
            if($cartItem['id'] == $productID)
            {
                $_SESSION['cart'][$cartKey]['qty'] = $productQty;
                $_SESSION['cart'][$cartKey]['total_price'] = $calculateTotalPrice;
                break;
            }
        }

        if(!in_array($productID,$productIDs))
        {
            $_SESSION['cart'][]= $cartArray;
        }

        $successMsg = true;

    }
    else
    {
        $_SESSION['cart'][]= $cartArray;
        $successMsg = true;
    }

}
function validate_input($input)
{
    $input = stripslashes(trim($input));
    $input = htmlentities($input, ENT_QUOTES);
    return $input;
}
if(isset($_POST['submit']))
{
    if(isset($_POST['comment'],$_POST['name'],$_POST['email']) && !empty($_POST['comment']) && !empty($_POST['name']) && !empty($_POST['email']))
    {
        $Comment = $_POST['comment'];

        if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
        {
            $errorMsg[] = 'Please enter valid email address';
        }
        else
        {
            //validate_input is a custom function
            $Comment = validate_input($_POST['comment']);
            $Name   = validate_input($_POST['name']);
            $email  = validate_input($_POST['email']);



            $host = 'localhost';
            $db = 'love_plant';
            $user = 'root';
            $pass = '';
            $charset = 'utf8';

            $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
            $opt = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            $pdo = new PDO($dsn, $user, $pass, $opt);



            $sql = 'insert into love_plant.feedback (comment,name, email, p_id, created_at, updated_at, user_id) values (:comment, :name, :email, :p_id,:created_at, :updated_at, :user_id)';
            $statement = $pdo->prepare($sql);
            $params = [
                'comment' => $Comment,
                'name' => $Name,
                'email' => $email,
                'p_id' => $_GET['id'],
                'created_at'=> date('Y-m-d H:i:s'),
                'updated_at'=> date('Y-m-d H:i:s'),
                'user_id' => $_SESSION['id']
            ];

            $statement->execute($params);

        }$id=$_GET['id'];
        echo '<script>window.location="product-details.php?page=detail&id='.$_GET['id'].'"</script>';
    }
}


?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - product details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->
<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li>product details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->
<?php
if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $sqlDetailPro = "SELECT * FROM products WHERE id = '$id'";
    $con=mysqli_connect("localhost","root","","love_plant");
    $resultDetailPro = mysqli_query($con, $sqlDetailPro)or die(mysqli_error($con));
    $rowProDetail = mysqli_fetch_row($resultDetailPro);
   // echo "<pre>";
    // print_r($rowProDetail);
?>
<?php if(isset($rowProDetail) && is_array($rowProDetail)){?>
<?php if(isset($successMsg) && $successMsg == true){?>
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <img src="assets/img/product/<?php echo $rowProDetail['4'] ?>" class="rounded img-thumbnail mr-2" style="width:40px;"><?php echo $rowProDetail['1']?> is added to cart. <a href="carts.php" class="alert-link">View Cart</a>
            </div>
        </div>
    </div>
<?php }?>
<?php }?>
<!--product details start-->
<div class="product_details mt-100 mb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="product-details-tab">
                    <div id="img-1" class="zoomWrapper single-zoom">
                        <a href="#">
                            <img id="zoom1" src="assets/img/product/<?php echo $rowProDetail['4']?>"
                                 data-zoom-image="assets/img/product/<?php echo $rowProDetail['4']?>" alt="big-1">
                        </a>
                    </div>

                </div>
            </div>

            <div class="col-lg-6 col-md-6">
                <div class="product_d_right">
                    <form action="#">

                        <h1><a href="#"><?php echo $rowProDetail['1']?></a></h1>

                        <div class=" product_ratting">
                            <ul>
                                <li><a href="#"><i class="icon-star"></i></a></li>
                                <li><a href="#"><i class="icon-star"></i></a></li>
                                <li><a href="#"><i class="icon-star"></i></a></li>
                                <li><a href="#"><i class="icon-star"></i></a></li>
                                <li><a href="#"><i class="icon-star"></i></a></li>
                                <li class="review"><a href="#"> (customer review ) </a></li>
                            </ul>

                        </div>
                        <div class="price_box">
                            <span class="current_price"><?php echo $rowProDetail['5']?>₸</span>
                            <span class="old_price"><?php echo $rowProDetail['6']?>₸</span>

                        </div>
                        <div class="product_desc">
                            <p><?php echo $rowProDetail['3']?> </p>
                        </div>

                        <div class="product_variant quantity" >
                            <form class="form-inline" method="POST">
                                <label>quantity</label>
                                <form class="form-inline" method="POST">
                                    <input type="number" formmethod="post" name="product_qty" id="productQty" class="form-control" placeholder="Quantity" min="1" max="1000" value="1">
                                    <input type="hidden" name="id" id="productID" formmethod="post" value="<?php echo $rowProDetail['0']?>">

                                    <button type="submit" formmethod="post" class="btn btn-primary" name="add_to_cart" value="add to cart">Add to Cart</button>
                                </form>
                            </form>
                        </div>

                        <div class=" product_d_action">
                            <ul>
                                <li><a href="#" title="Add to wishlist">+ Add to Wishlist</a></li>

                            </ul>
                        </div>

                    </form>
                    <div class="priduct_social">
                        <ul>
                            <li><a class="facebook" href="#" title="facebook"><i class="fa fa-facebook"></i>
                                    Like</a></li>
                            <li><a class="twitter" href="#" title="twitter"><i class="fa fa-twitter"></i> tweet</a>
                            </li>
                            <li><a class="pinterest" href="#" title="pinterest"><i class="fa fa-pinterest"></i>
                                    save</a></li>
                            <li><a class="google-plus" href="#" title="google +"><i class="fa fa-google-plus"></i>
                                    share</a></li>
                            <li><a class="linkedin" href="#" title="linkedin"><i class="fa fa-linkedin"></i>
                                    linked</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!--product details end-->

<!--product info start-->
<div class="product_d_info mb-90">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product_d_inner">
                    <div class="product_info_button">
                        <ul class="nav" role="tablist">
                            <li>
                                <a class="active" data-toggle="tab" href="#info" role="tab" aria-controls="info"
                                   aria-selected="false">Description</a>
                            </li>

                            <li>
                                <a data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews"
                                   aria-selected="false">Reviews</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="info" role="tabpanel">
                            <div class="product_info_content">
                                <p><?php echo $rowProDetail['3'];?></p>
                                <p><?php echo $rowProDetail['7'];?></p>

                            </div>
                        </div>

                        <?php } ?>
                        <div class="tab-pane fade" id="reviews" role="tabpanel">
                            <div class="reviews_wrapper">



                                <?php if (!empty($review)): ?>
                                    <h2> review for <?= $rowProDetail['1']?></h2>
                                    <?php foreach ($review as $r): ?>
                                <?php if (($_GET['id'])==$r['p_id']): ?>
                                <div class="reviews_comment_box">

                                    <div class="comment_thmb">
                                        <img src="assets/img/blog/comment2.jpeg" alt="">
                                    </div>

                                    <div class="comment_text">

                                        <div class="reviews_meta">

                                            <p><strong><?= $r['name']?> </strong><?= $r['created_at']?>  Email:<?= $r['email']?></p>

                                            <span><?= $r['comment']?></span>
                                        </div>
                                    </div>



                                </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>


                                <div class="product_review_form">
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-12">
                                                <label for="review_comment">Your review </label>
                                                <textarea formmethod="post" id="Comment" name="comment" placeholder="" class="form-control"></textarea>
                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <label for="author">Name</label>
                                                <input   formmethod="post" id="Name" name="name" type="text" placeholder="<?php echo $_SESSION['username']; ?>" value="<?php echo $_SESSION['username'];?>" class="form-control">

                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <label for="email">Email </label>
                                                <input formmethod="post" name="email" id="email" type="text"  class="form-control">
                                            </div>
                                        </div>
                                        <button  type="submit" formmethod="post" name="submit" value="submit" >Submit</button>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--product info end-->


<!--product area start-->
<section class="product_area related_products">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Related Products </h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="product_carousel product_column4 owl-carousel">
                <?php
                include ('inc/db.php');

                $query=$pdo->prepare("select *from love_plant.products LIMIT 0,12");
                $query->execute();

                while($row=$query->fetch()):?>
                <div class="col-lg-3">

                    <article class="single_product">
                        <figure>

                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php?page=detail&id=<?= $row['id']?>"><img
                                        src="assets/img/product/<?= $row['img']?>" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">-7%</span>
                                </div>

                            </div>
                            <figcaption class="product_content">
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="icon-star"></i></a></li>
                                        <li><a href="#"><i class="icon-star"></i></a></li>
                                        <li><a href="#"><i class="icon-star"></i></a></li>
                                        <li><a href="#"><i class="icon-star"></i></a></li>
                                        <li><a href="#"><i class="icon-star"></i></a></li>
                                    </ul>
                                </div>
                                <h4 class="product_name"><a href="product-details.html"><?php echo $row['title']?></a></h4>
                                <div class="price_box">
                                    <span class="current_price"><?= $row['price']?>₸</span>
                                    <span class="old_price"><?= $row['old_price']?>₸</span>
                                </div>
                            </figcaption>


                        </figure>
                    </article>

                </div>
                <?php endwhile;?>
            </div>
        </div>
    </div>
</section>
<!--product area end-->

<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include ('assets/layouts/footer.php');?>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<!--jquery min js-->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>
<script src="assets/js/web.js"></script>

</body>

</html>