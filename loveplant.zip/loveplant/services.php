<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - services page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/jpg" href="assets/img/994.jpg"/>
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">



    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>


<!--header area start-->
<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Services</h3>
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li>our services</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--services img area-->
<div class="services_gallery mt-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="single_services">
                    <div class="services_thumb">
                        <img src="assets/img/service/114.jpg" alt="">
                    </div>
                    <div class="services_content">
                        <h3>Plant service for your home</h3>
                        <p>You can contact our company to take care of your plants. Our employees can come
                            to your home and check the condition of the plant</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single_services">
                    <div class="services_thumb">
                        <img src="assets/img/service/201.jpg" alt="">
                    </div>
                    <div class="services_content">
                        <h3>Plant service for organization</h3>
                        <p>You can contact our company to take care of your plants. Our staff will help you keep
                            the plant healthy for your event and check their condition.</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single_services">
                    <div class="services_thumb">
                        <img src="assets/img/service/206.jpg" alt="">
                    </div>
                    <div class="services_content">
                        <h3>Plant service for the office</h3>
                        <p>You can contact our company to take care of your plants. Our employees will check
                            and replace the plant every month in the offices to keep them in good condition.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--services img end-->

<!--our services area-->
<div class="our_services">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="services_title">
                    <h2>OUR SERVICES</h2>
                    <p>Plants are a great way to bring warmth and life to any space.Our company and their staff
                        will help you inspect,
                        check and take care of the condition of the plant. We offer the following services:
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="fa fa-ambulance" aria-hidden="true"></i>
                    </div>
                    <div class="services_desc">
                        <h3>CALLING</h3>
                        <p>Our employees are always ready to go where your plant is.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="	fa fa-medkit"></i>
                    </div>
                    <div class="services_desc">
                        <h3>TREATMENT</h3>

                        <p>Our staff is always ready to heal your favorite plants for organizations and offices.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">

                        <i class="fa fa-camera"></i>

                    </div>
                    <div class="services_desc">
                        <h3>PHOTOGRAPHY</h3>

                        <p>From the photos we will help you find the treatment of your plants.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="	fa fa-heart"></i>
                    </div>
                    <div class="services_desc">
                        <h3>CARE</h3>
                        <p>If you are on a business trip or you have urgent business, you can leave your plant with us.
                            We will take care until your return.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="fa fa-stethoscope" aria-hidden="true"></i>
                    </div>
                    <div class="services_desc">
                        <h3>INSPECTION</h3>
                        <p>Our employees check and monitor the condition of your plants
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>
                    </div>
                    <div class="services_desc">
                        <h3>REPLACEMENT</h3>
                        <p>If the plant is unusable, we can replace them with a new plant.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="fa fa-headphones"></i>
                    </div>
                    <div class="services_desc">
                        <h3>SUPPORT</h3>
                        <p>You can always contact us on the call center and website.
                            We are always ready to answer all your questions.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="services_item">
                    <div class="services_icone">
                        <i class="fa fa-leaf"></i>
                    </div>
                    <div class="services_desc">
                        <h3>GRAPHIC DESIGN</h3>
                        <p>We will help you in sketching decorations for your premises.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--our services area end-->


<!--services section area-->
<div class="unlimited_services">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div class="services_section_thumb">
                    <img src="assets/img/service/994.jpg" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="unlimited_services_content">
                    <h1>UNLIMITED IDEAS</h1>
                    <p>Plants are a great way to bring warmth and life to any space. The key to decorating with plants
                        is that you should never use just one.  Either use them as a balanced pair in corners or entryways or
                        layer multiple plants of various sizes.  Keep the color of the leaves complementary. For example,
                        use light green foliage together for a tropical look or dark greens for a more modern or sophisticated style. </p>
                    <div class="view__work">
                        <a href="index-3.html">MORE INFO <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--services section end-->

<!--price table area -->
<div class="priceing_table">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="single_priceing">
                    <div class="priceing_title">
                        <h1>Standard</h1>
                    </div>
                    <div class="priceing_list">
                        <h1><span>350К+ tg</span></h1>
                        <ul>
                            <li>Decoration</li>
                            <li>Chamaecyparis</li>
                            <li>Zamiokulkas</li>
                            <li>tsikas (cycad)</li>

                        </ul>
                        <a href="#">purchase now </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single_priceing">
                    <div class="priceing_title">
                        <h1>Returns</h1>
                    </div>
                    <div class="priceing_list">
                        <h1><span>550K+ tg</span></h1>
                        <ul>
                            <li>Decoration</li>
                            <li>Kalanchoe</li>
                            <li>Room roses</li>
                            <li>Ficus</li>
                        </ul>
                        <a class="list_button" href="#">purchase now </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single_priceing">
                    <div class="priceing_title">
                        <h1>Affiliate</h1>
                    </div>
                    <div class="priceing_list">
                        <h1><span>750K+ tg</span></h1>
                        <ul>
                            <li>Decoration</li>
                            <li>Soil and medicines</li>
                            <li>Cissus</li>
                            <li>Hedera</li>
                            <li>Syngonium</li>
                        </ul>
                        <a href="#">purchase now </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single_priceing">
                    <div class="priceing_title">
                        <h1>Specials</h1>
                    </div>
                    <div class="priceing_list">
                        <h1><span>900K + tg</span></h1>
                        <ul>
                            <li>Decoration</li>
                            <li>Soil and medicines</li>
                            <li>Monthly check</li>
                            <li>Room flowers</li>
                            <li>Cissus</li>
                            <li>Hedera</li>

                        </ul>
                        <a class="list_button" href="#">purchase now </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--price table  end-->


<!--header area start-->
<?php include('assets/layouts/footer.php');?>
<!--header area end-->

<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>




</body>

</html>