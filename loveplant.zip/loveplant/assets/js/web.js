
function plus(){
    let num = parseInt($('#quantity').val());
    let tem = num + 1;
    $("#quantity").val(tem);
}
function minus(){
    let num = parseInt($('#quantity').val());
    let tem;
    if (num > 1) {
        tem = num - 1;
    }
    $("#quantity").val(tem);
}
function showCart(cart) {
    $('#mini-cart .modal-cart-content').html(cart);
    $('#mini-cart').modal();

    let cartQty = $('#modal-cart-qty').text() ? $('#modal-cart-qty').text() : 0;
    $('.mini-cart-qty').text(cartQty);
}
function addCart(id){
    let num = parseInt($('#quantity').val());
    $.ajax({
            url: 'cart.php',
            type: 'GET',
            data: {cart: 'add', id: id, num:num},
            dataType: 'json',
            success: function(res){
                if(res.code == 'ok') {
                    showCart(res.answer);
                }else {
                    alert(res.answer);
                }
            },
            error: function (res){
                alert('ERROR');
            }
        });

    $('#get-cart').on('click', function (e) {
        e.preventDefault();

        $.ajax({
            url: 'cart.php',
            type: 'GET',
            data: {cart: 'show'},
            success: function (res) {
                showCart(res);
            },
            error: function () {
                alert('Error');
            }
        });
    });
}

$(".upqty").change(function(){
    let id = $(this).data('id');
    let qty = $(this).val();
    $.ajax({
        type:'POST',
        url:'cart.php',
        dataType: 'json',
        data: {action:'update-qty', id: id, qty: qty},
        success:function(data){
            if (data.msg == 'success')
            {
                window.location.href='carts.php';
            }
        }
    });
});