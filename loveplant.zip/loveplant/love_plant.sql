-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 18 2022 г., 19:00
-- Версия сервера: 5.6.41
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `love_plant`
--

-- --------------------------------------------------------

--
-- Структура таблицы `checkout`
--

CREATE TABLE `checkout` (
  `id` int(16) NOT NULL,
  `first_name` varchar(256) NOT NULL,
  `last_name` varchar(256) NOT NULL,
  `city` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `address2` varchar(256) NOT NULL,
  `phone` text NOT NULL,
  `email` varchar(256) NOT NULL,
  `total_price` float(20,2) NOT NULL,
  `order_status` varchar(256) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `card_number` int(25) NOT NULL,
  `expiry_month` int(11) NOT NULL,
  `expiry_year` int(11) NOT NULL,
  `cvc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `checkout`
--

INSERT INTO `checkout` (`id`, `first_name`, `last_name`, `city`, `address`, `address2`, `phone`, `email`, `total_price`, `order_status`, `created_at`, `updated_at`, `user_id`, `card_number`, `expiry_month`, `expiry_year`, `cvc`) VALUES
(14, 'Ahsan', 'Zameer', 'dd', 'L-14 Gulshan-e-Malir, Malir Halt Karachi', 'L-14 Gulshan-e-Malir, Malir Halt Karachi', '77472454517', 'ahsnzmeerkhan@gmail.com', 3.00, 'confirmed', '2022-05-19 13:32:31', '2022-05-19 13:32:31', 5, 0, 0, 0, 0),
(64, '123', 'Rysbaev', 'Almaty', 'Abaya koshesi 25', 'Abaya koshesi 25', '87472454517', 'kolkanat@gmail.com', 3450.00, 'confirmed', '2022-06-06 01:41:28', '2022-06-06 01:41:28', 0, 2147483647, 12, 2001, 123),
(65, 'Kolkanat', 'Rysbaev', 'Almaty', 'Abaya koshesi 25', 'Abaya koshesi 25', '77472454517', 'kolkanat@gmail.com', 6900.00, 'confirmed', '2022-06-06 03:04:54', '2022-06-06 03:04:54', 0, 2147483647, 12, 2022, 123),
(66, 'Kolkanat', 'Rysbaev', 'Almaty', 'Abaya koshesi 25', 'Abaya koshesi 25', '77472454517', 'kolkanat@gmail.com', 7140.00, 'confirmed', '2022-06-06 03:22:34', '2022-06-06 03:22:34', 0, 2147483647, 9, 2022, 123),
(67, 'Kolkanat', 'Rysbaev', 'Almaty', 'Abaya koshesi 25', 'Abaya koshesi 25', '77472454517', 'kolkanat@gmail.com', 3450.00, 'confirmed', '2022-06-06 03:29:13', '2022-06-06 03:29:13', 0, 2147483647, 8, 2022, 123),
(68, 'Kolkanat', 'Rysbaev', 'Almaty', 'Abaya koshesi 25', 'Abaya koshesi 25', '77472454517', 'kolkanat@gmail.com', 7230.00, 'confirmed', '2022-06-06 03:37:06', '2022-06-06 03:37:06', 0, 2147483647, 12, 2025, 123);

-- --------------------------------------------------------

--
-- Структура таблицы `contact`
--

CREATE TABLE `contact` (
  `id` int(16) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `Subject` varchar(256) NOT NULL,
  `Message` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contact`
--

INSERT INTO `contact` (`id`, `Name`, `Email`, `Subject`, `Message`) VALUES
(1, '', 'dsvsdvsdv@dsdsf.ds', 'fdfdfd', 'fdffdfdf'),
(2, '', 'dsvsdvsdv@dsdsf.ds', 'fdvf', 'dfdf'),
(3, '', 'dsvsdvsdv@dsdsf.ds', 'dddd', 'ddd'),
(4, 'dddddd', 'dsvsdvsdv@dsdsf.ds', 'ddd', 'dddddddddd'),
(5, 'hbhb', 'f@gmail.com', 'hjgjgjhg', 'ghfhgghjhjh'),
(6, '123', 'f@gmail.com', 'hdhd', 'jdnjbd'),
(7, 'ff', 'fff@hjdj.jj', 'ff', 'f'),
(8, 'ff', 'f@gmail.com', 'ffffffffffffffffffffffffffffffff', 'fffffffffffffffffffffffffffffffffffffffff'),
(9, 'dffd', 'fff@hjdj.jj', 'f', 'fffffffffffffff'),
(10, 'ffc', 'fff@hjdj.jj', 'f', 'fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'),
(11, 'kolkanat', 'kolkanat@gmail.com', 'Plants', 'plants');

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `comment` varchar(300) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `p_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id`, `comment`, `name`, `email`, `p_id`, `created_at`, `updated_at`, `user_id`) VALUES
(17, 'Cood product', 'Almat', 'kolkanat@gmail.com', 3, '2022-06-02 16:29:25', '2022-06-02 16:29:25', 0),
(18, 'Thanks', 'Kanagat', 'f@gmail.com', 3, '2022-06-02 16:29:50', '2022-06-02 16:29:50', 0),
(19, 'jjj', '123', 'df@gmail.com', 1, '2022-06-02 16:55:31', '2022-06-02 16:55:31', 0),
(20, 'Great', '123', 'f@gmail.com', 6, '2022-06-02 18:19:53', '2022-06-02 18:19:53', 0),
(21, 'Great', '123', 'f@gmail.com', 7, '2022-06-02 19:56:13', '2022-06-02 19:56:13', 0),
(22, 'To plant a garden is to believe in tomorrow', '123', 'f@gmail.com', 6, '2022-06-02 19:58:01', '2022-06-02 19:58:01', 0),
(23, 'Life begins the day you start a garden', '123', 'f@gmail.com', 6, '2022-06-02 19:58:42', '2022-06-02 19:58:42', 0),
(24, 'Good', '123', 'f@gmail.com', 6, '2022-06-02 19:59:15', '2022-06-02 19:59:15', 5),
(30, 'hjghjre', '123', 'fff@gmail.com', 2, '2022-06-05 23:26:45', '2022-06-05 23:26:45', 0),
(31, 'ddddddddddddd', '123', 'kolkanat@gmail.com', 2, '2022-06-05 23:28:09', '2022-06-05 23:28:09', 5),
(32, 'Good', 'Kolkanat', 'kolkanat@gmail.com', 3, '2022-06-06 03:03:24', '2022-06-06 03:03:24', 10),
(33, 'Thanks', 'Kolkanat', 'kolkanat@gmail.com', 3, '2022-06-06 03:13:54', '2022-06-06 03:13:54', 11),
(34, 'Good products', 'kolkanat', 'kolkanat@gmail.com', 8, '2022-06-06 03:21:18', '2022-06-06 03:21:18', 12),
(35, 'Good', 'Kolkanat', 'kolkanat@gmail.com', 3, '2022-06-06 03:28:14', '2022-06-06 03:28:14', 13),
(36, 'good product', '123', 'kolkanat@gmail.com', 1, '2022-06-06 03:36:08', '2022-06-06 03:36:08', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `feedback_blog`
--

CREATE TABLE `feedback_blog` (
  `id` int(11) NOT NULL,
  `comment` varchar(300) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `p_id` int(11) NOT NULL,
  `image` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `feedback_blog`
--

INSERT INTO `feedback_blog` (`id`, `comment`, `name`, `email`, `p_id`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Thank you', '123', 'f@gmail.com', 7, '', '2022-06-02 20:48:12', '2022-06-02 20:48:12'),
(2, 'Nice post . Thank you for posting something like this', '123', 'f@gmail.com', 7, '', '2022-06-02 21:05:14', '2022-06-02 21:05:14'),
(8, 'I read this post your post so nice and very informative post thanks for sharing this post', 'kolkanat', 'f@gmail.com', 8, '', '2022-06-03 12:38:55', '2022-06-03 12:38:55'),
(9, 'Your Blog is very nice.\r\nWish to see much more like this. Thanks for sharing your information', 'kolkanat', 'f@gmail.com', 8, '', '2022-06-03 13:49:19', '2022-06-03 13:49:19'),
(11, 'Greate Blog , and good job', 'kolkanat', 'f@gmail.com', 1, '', '2022-06-03 13:52:22', '2022-06-03 13:52:22'),
(25, 'Thank you so much for letting me express my feeling about your post.\r\nYou write every blog post so well. Keep the hard work going and good luck.\r\nHope to see such beneficial post ahead to. ', 'kolkanat', 'df@gmail.com', 1, '', '2022-06-03 14:31:07', '2022-06-03 14:31:07'),
(26, 'I got know your article’s Content and your article skill both are always good. Thanks for sharing this article this content is very significant for me I really appreciate you', 'kolkanat', 'f@gmail.com', 1, '', '2022-06-03 14:31:20', '2022-06-03 14:31:20'),
(27, 'Amazing post, thanks for sharing this article. I am truly motivated by you for blogging.\r\nThank You', 'kolkanat', 'fff@gmail.com', 1, '', '2022-06-03 14:32:29', '2022-06-03 14:32:29'),
(28, 'Post is very useful.Thank you this usefull information.\r\nkids teaching world provides a great way to teaching kids with the help of visualisation and sound.', 'kolkanat', 'fff@gmail.com', 1, '', '2022-06-03 14:33:35', '2022-06-03 14:33:35'),
(30, 'Very good this content, thanks for sharing', '123', 'f@gmail.com', 2, '', '2022-06-04 07:53:48', '2022-06-04 07:53:48'),
(32, 'good', 'kolkanat', 'kolkanat@gmail.com', 10, '', '2022-06-06 03:19:23', '2022-06-06 03:19:23'),
(33, 'good post', '123', 'kolkanat@gmail.com', 10, '', '2022-06-06 03:39:02', '2022-06-06 03:39:02');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `payerID` varchar(300) DEFAULT NULL,
  `paymentID` varchar(400) DEFAULT NULL,
  `token` varchar(400) DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`oid`, `payerID`, `paymentID`, `token`, `pid`, `user_id`) VALUES
(1, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(2, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(3, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(4, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(5, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(6, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(7, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(8, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(9, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(10, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(11, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(12, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(13, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(14, 'X8RANJCW2J9ZL', 'PAYID-MKKPMTI97L09959U57146719', 'EC-46C9225433125353F', 0, 0),
(15, 'X8RANJCW2J9ZL', 'PAYID-MKKPTUI42872548BR831661H', 'EC-2KA76978YA1847139', 0, 5),
(16, 'X8RANJCW2J9ZL', 'PAYID-MKKPTUI42872548BR831661H', 'EC-2KA76978YA1847139', 0, 0),
(17, 'X8RANJCW2J9ZL', 'PAYID-MKK3GPA9V232551DL3341422', 'EC-4Y58528824053634T', 0, 0),
(18, 'X8RANJCW2J9ZL', 'PAYID-MKK3GPA9V232551DL3341422', 'EC-4Y58528824053634T', 0, 0),
(19, 'X8RANJCW2J9ZL', 'PAYID-MKLOXTI9VY938097W759780A', 'EC-27F86275FM520354X', 0, 0),
(20, 'X8RANJCW2J9ZL', 'PAYID-MKLOXTI9VY938097W759780A', 'EC-27F86275FM520354X', 0, 0),
(21, 'X8RANJCW2J9ZL', 'PAYID-MKLOXTI9VY938097W759780A', 'EC-27F86275FM520354X', 0, 0),
(22, 'X8RANJCW2J9ZL', 'PAYID-MKNOW3Q6UG49724EY991570P', 'EC-6RP7362587566291H', 12, 5),
(28, 'X8RANJCW2J9ZL', 'PAYID-MKOTTOI9WJ338153N347320F', 'EC-21S22894NU225600D', 8, 5),
(29, 'X8RANJCW2J9ZL', 'PAYID-MKOUR4A5ME964921W440811Y', 'EC-35G802934N664912Y', 2, 12),
(30, 'X8RANJCW2J9ZL', 'PAYID-MKOUU4I1BW31430RL115040P', 'EC-96501760X1881641S', 7, 13),
(31, 'X8RANJCW2J9ZL', 'PAYID-MKOUYTA7178576747111372H', 'EC-18U510362X337450T', 4, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `price` float(6,2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `total_price` float(20,2) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `order_status` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `title`, `price`, `qty`, `total_price`, `user_id`, `created_at`, `order_status`) VALUES
(1, 11, 0, 'Ceramic pot for plants', 3500.00, 1, 0.00, 0, '0000-00-00 00:00:00', ''),
(2, 14, 0, 'Ceramic pot for plants', 3500.00, 1, 3.00, 0, '0000-00-00 00:00:00', ''),
(3, 16, 0, 'Polyscias Fabian', 3450.00, 1, 0.00, 0, '0000-00-00 00:00:00', ''),
(4, 16, 0, 'Sansevieria Zeylanica', 3690.00, 10, 36.00, 0, '0000-00-00 00:00:00', ''),
(5, 21, 0, 'Codiaum motley ', 5790.00, 5, 28.00, 0, '0000-00-00 00:00:00', ''),
(6, 21, 0, 'Ceramic pot for plants', 3500.00, 1, 3.00, 0, '0000-00-00 00:00:00', ''),
(7, 22, 0, 'Polyscias Fabian', 3450.00, 6, 20.00, 0, '0000-00-00 00:00:00', ''),
(8, 23, 0, 'Polyscias Fabian', 3450.00, 6, 20.00, 0, '0000-00-00 00:00:00', ''),
(9, 24, 0, 'Ceramic pot for plants', 3500.00, 10, 35.00, 0, '0000-00-00 00:00:00', ''),
(10, 29, 0, 'Codiaum motley ', 5790.00, 1, 0.00, 0, '0000-00-00 00:00:00', ''),
(11, 30, 0, 'Ceramic pot for plants', 3500.00, 1, 3.00, 0, '0000-00-00 00:00:00', ''),
(12, 31, 0, 'Ceramic pot for plants', 3500.00, 1, 3.00, 0, '0000-00-00 00:00:00', ''),
(13, 32, 0, 'Money Tree', 3780.00, 10, 37.00, 0, '0000-00-00 00:00:00', ''),
(14, 33, 0, 'Money Tree', 3780.00, 10, 37.00, 0, '0000-00-00 00:00:00', ''),
(15, 34, 0, 'Ceramic pot for plants', 3500.00, 9, 31.00, 0, '0000-00-00 00:00:00', ''),
(16, 35, 0, 'Ceramic pot for plants', 3500.00, 7, 24.00, 0, '0000-00-00 00:00:00', ''),
(17, 36, 0, 'Ceramic pot for plants', 3500.00, 4, 14.00, 5, '2022-06-03 23:15:00', 'completed'),
(18, 37, 0, 'Ceramic pot for plants', 3500.00, 10, 35.00, 5, '0000-00-00 00:00:00', ''),
(19, 38, 0, 'Echeveria elegans', 3690.00, 10, 36.00, 0, '0000-00-00 00:00:00', ''),
(20, 39, 0, 'Ceramic pot for plants', 3500.00, 10, 35.00, 0, '0000-00-00 00:00:00', ''),
(21, 40, 0, 'Sansevieria Zeylanica', 3690.00, 10, 36.00, 0, '0000-00-00 00:00:00', ''),
(22, 41, 0, 'Aloe Brevifolia', 2500.00, 10, 25.00, 0, '0000-00-00 00:00:00', ''),
(23, 42, 0, 'Ceramic pot for plants', 3500.00, 19, 66500.00, 0, '0000-00-00 00:00:00', ''),
(24, 43, 0, 'Polyscias Fabian', 3450.00, 10, 34500.00, 0, '0000-00-00 00:00:00', ''),
(25, 45, 3, 'Polyscias Fabian', 3450.00, 5, 17250.00, 0, '0000-00-00 00:00:00', ''),
(26, 46, 8, 'Echeveria elegans', 3690.00, 1, 3690.00, 0, '0000-00-00 00:00:00', ''),
(27, 46, 6, 'Umbra Trigg ', 3690.00, 1, 7380.00, 0, '0000-00-00 00:00:00', ''),
(28, 46, 7, 'Sansevieria Zeylanica', 3690.00, 4, 22140.00, 0, '0000-00-00 00:00:00', ''),
(29, 47, 8, 'Echeveria elegans', 3690.00, 1, 3690.00, 5, '2022-06-03 20:42:59', 'confirmed'),
(30, 63, 0, 'Ceramic pot for plants', 3500.00, 1, 3500.00, 0, '0000-00-00 00:00:00', ''),
(31, 64, 0, 'Polyscias Fabian', 3450.00, 1, 3450.00, 5, '0000-00-00 00:00:00', ''),
(32, 65, 0, 'Polyscias Fabian', 3450.00, 2, 6900.00, 10, '0000-00-00 00:00:00', ''),
(33, 66, 0, 'Polyscias Fabian', 3450.00, 1, 3450.00, 12, '0000-00-00 00:00:00', ''),
(34, 66, 0, 'Echeveria elegans', 3690.00, 1, 7140.00, 12, '0000-00-00 00:00:00', ''),
(35, 67, 0, 'Polyscias Fabian', 3450.00, 1, 3450.00, 13, '0000-00-00 00:00:00', ''),
(36, 68, 0, 'Polyscias Fabian', 3450.00, 1, 3450.00, 5, '0000-00-00 00:00:00', ''),
(37, 68, 0, 'Money Tree', 3780.00, 1, 7230.00, 5, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `id` int(25) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `image`, `body`, `published`, `created_at`) VALUES
(1, 8, 3, 'How to take care of different types of plants', 'blog1.jpg', '&lt;p&gt;If you\'re a new plant parent, all of the care that goes into keeping your houseplants happy can feel a little overwhelming at first. However, most of your plants won\'t need constant attention to stay healthy. Other than remembering to water, there are plenty of easy-care houseplants that will only need a little maintenance a few times each year. When you need to step in and do some pruning or snip away a few leaves that are starting to turn yellow, these tips will give you the knowledge you need to care for your plants with confidence.&lt;/p&gt;&lt;blockquote&gt;&lt;p&gt;&lt;i&gt;Plants, both indoors and out, are lovely additions to any d&eacute;cor. They are generally easy to take care of and maintain, and will thrive when given proper care and treatment. Whether you\'re unsure of how to care for your plants or you just want to make sure you\'ve done your homework, read on to Step One for information on properly caring for indoor and garden plants&lt;/i&gt;&lt;/p&gt;&lt;/blockquote&gt;&lt;p&gt;1. Watering Your Houseplants&lt;/p&gt;&lt;p&gt;1. Watering Your Houseplants All houseplants have slightly different watering requirements, depending on how they\'re grown and changes in plant growth through the seasons. It\'s best to water on an as-needed basis rather than by a set calendar schedule. In general, plants grown in well-drained soil in an appropriate-size container should be watered when the top 1/2 to 1 inch of soil feels dry. Cacti and succulents need less water; flowering plants usually need slightly more. Overwatering is one of the most common causes of houseplant death. If you\'re not sure how much to water, it\'s better to err on the dry side than to give your plants too much moisture.&lt;/p&gt;&lt;p&gt;2. Fertilize Houseplants Periodically Like watering&lt;/p&gt;&lt;p&gt;Fertilize Houseplants Periodically Like watering, there\'s not an easy rule to know how much to fertilize: It depends on the plant\'s growth rate and age, and the time of year. Most houseplants put on a growth spurt in spring and summer, so this is the best time to fertilize them. During the short days of fall and winter, most houseplants don\'t need much, if any, fertilizer. Follow label directions to know how much plant food to use.&lt;/p&gt;&lt;p&gt;3. Propagate Houseplants When Needed&lt;/p&gt;&lt;p&gt;Several types of houseplants benefit from being propagated by division or other methods once in a while. It helps to rejuvenate an overgrown plant and encourage fresh growth. Plus, it\'s an inexpensive way to get more plants out of the ones you already have.&lt;/p&gt;', 1, '2022-05-23 04:08:14'),
(10, 5, 4, 'Basics of creating flower arrangements', 'blogdecor.jpg', '&lt;p&gt;Basics of creating flower arrangements&lt;br&gt;To create the maximum decorative effect in phytodesign, home plants are used to create compositions, turning ordinary bushes into elegant interesting mini-gardens or arranging pots according to a certain pattern. But in order for plants or their groups to fit well into the interior, it is important to remember the basic compositional rules:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;The game of contrasts will help to attract attention. The appearance of landings in one group should not completely coincide with each other. Contrast can also be observed when choosing a container. A modest flower can be planted in a bright or unusual pot, and for a lush and attractive tropical bush with large flowers or variegated leaves, a discreet container is chosen. So it will not distract from the plant itself. The background of the room itself also matters. Light walls will favorably emphasize plantings with multi-colored foliage or richly colored flowers;&lt;/li&gt;&lt;li&gt;The center is chosen in the composition - one or two of the most impeccable plants that attract the eye in the first place. The rest of the pots are centered around them, using less visible plants as a backdrop.&lt;/li&gt;&lt;li&gt;The size of pots and plantings should be proportional to the area of ​​​​the room. Massive containers with bushes or trees in a small room will not look as impressive as in a large spacious hall. In addition, such compositions will take up a lot of space and visually reduce the space.&lt;/li&gt;&lt;li&gt;You should not use too many plantings for compositions without having enough experience and space to grow them. Different species are trying to be placed in separate pots, and not planted in a common container. This will simplify care and insure the roots from crowding;&lt;/li&gt;&lt;li&gt;Many houseplants prefer high humidity, so to maintain the beauty of large flower arrangements, care should be taken to install a humidifier. The level of illumination and the irrigation system are also thought out in advance. If the plant owner does not have the opportunity to regularly care for numerous flowers, they try to automate watering. If the flowers will be watered by hand, it should be convenient to get to them.&lt;/li&gt;&lt;/ul&gt;', 1, '2022-06-05 23:44:52'),
(11, 5, 4, 'Florarium', 'florarium-fitodizain.jpg', '&lt;p&gt;The lack of time or space for breeding flowers, or suitable conditions for their cultivation is not a reason to completely abandon gardening. Florariums &mdash; vessels for creating mini-gardens are gaining more and more popularity. Their sizes may vary, but the principle of operation does not change. Growing flowers in a glass container allows them to form their own ecosystem there. Florariums are purchased ready-made or created independently.&lt;/p&gt;&lt;p&gt;&lt;i&gt;As a rule, medium-sized plantings are used for growing in vessels, which like a high level of humidity. For these purposes, ferns, reo, moss and other similar crops can be used. The basis of the florarium can be either a small aquarium or any glass vessel of high strength. Bottles or cans of fancy shape will look the most interesting. In addition to the container, you should stock up on soil, drainage elements and compost, as well as decorative elements to decorate the finished garden. Their role can be performed by ordinary or colored stones, small figures, etc.&lt;/i&gt;&lt;/p&gt;&lt;ol&gt;&lt;li&gt;The selected container must be washed, making sure that there is no dirt or traces of food on its walls;&lt;/li&gt;&lt;li&gt;Drainage is placed on the bottom of the container, a layer of compost is placed on top of it;&lt;/li&gt;&lt;li&gt;A mixture of a soil substrate with elements that improve the quality of the soil is poured onto the compost: vermiculite or coffee grounds. Such additives will allow the soil to retain moisture longer. The vessel is filled with about a third of the earth and the substrate is moistened;&lt;/li&gt;&lt;li&gt;The ground is carefully leveled with a stick, preparing holes for planting with it;&lt;/li&gt;&lt;li&gt;After planting, the plants are lightly watered;&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;&lt;br&gt;When all the inhabitants of the florarium are planted, you can decorate it with decorative elements.&lt;br&gt;The main requirements for florarium plants are unhurried growth and similar care. Due to the fact that the glass absorbs a certain amount of sunlight, it is optimal to place the container in places with sufficient illumination so that plants can develop normally. To create a brighter composition in the florarium, you can use dried flowers or colorful pebbles. Such a colorful island, without a doubt, will give the space of your room a special uniqueness.&lt;/p&gt;', 1, '2022-06-05 23:53:08'),
(12, 5, 6, 'Indoor garden', 'komnatniy-sadik.jpg', '&lt;p&gt;This variant of the &lt;strong&gt;phytodesign &lt;/strong&gt;of interiors is represented by the group placement of plants in a low container. Almost any container can be used as a container: a basket, a basin, a box made of wood or plastic, a special ceramic pot. The plants that will make up the composition can be planted together, or separately, each in its own pot.&lt;br&gt;&lt;br&gt;When choosing a joint planting, it should be taken into account that the selected plants should have the same requirements for soil, light, humidity. Only in this case, your tiny garden farm will delight for a long time with its healthy and beautiful appearance. The most optimal way would be to use relatives from the same family for the kindergarten.&lt;/p&gt;&lt;p&gt;When the participants of the garden grow in separate containers, they are placed on a drainage layer of expanded clay pebbles and fill the empty space between the pots with peat so that the edges are invisible. Separate placement gives greater freedom of choice when buying plants, because each care is carried out individually. At the same time, plants can be selected according to their external qualities and lighting requirements. In addition, if desired, you can get the desired plant and change it to another, thus updating the garden.&lt;/p&gt;&lt;p&gt;Regardless of the technology of placing plants in a container, it is necessary to adhere to uniform layout rules. The overall height of the composition usually depends on the main plant. The color of the foliage and the height of the stems should be in a harmonious combination with each other and the size of the container. In the center of the garden, it is best to place shade-tolerant plants, and cover the edges of the container with ampels.&lt;/p&gt;&lt;p&gt;Skillfully selected plants, the addition of the composition with pebbles or shells is an opportunity to create many variants of indoor gardens that repeat the natural landscape. They will become a bright note in the perception of your interior and will create coziness and comfort in the house.&lt;/p&gt;', 1, '2022-06-06 00:03:04'),
(13, 5, 3, 'Green plants for different interior styles', 'fitodizain-stili.jpg', '&lt;p&gt;Plants for phyto-compositions can be selected based on the available interior style. Large bushes or trees with clear outlines of the crown and rounded foliage fit perfectly into a classic setting. These can be ficuses, dracaena, monstera or such decorative flowering species as azalea. Pots for them can be made in antique style.&lt;/p&gt;&lt;p&gt;For the high-tech style, they try to select plants with bright foliage that can create a sense of lightness and dynamics. It can be either an elongated amaryllis or a hippeastrum, or a more romantic gardenia. Pots for such flowers are chosen according to the rules of the interior. Laconic containers of metal coloring will be appropriate here.&lt;/p&gt;&lt;blockquote&gt;&lt;p&gt;Art Nouveau involves the use of elegantly shaped plantings, as well as neat and medium-sized plants. Both palm trees or ficus trees and cacti can fit into such an environment. Pots here can be decorated with mosaics or paintings.&lt;/p&gt;&lt;p&gt;If the situation in the room obeys the rules of any ethnic direction, they try to concentrate the planting most typical for this country in it. African motifs and safari style suggest the planting of bright exotic cultures: guzmanias, pineapples, palm trees. Sand, stones and other natural materials, for example, rattan, are added to the composition with such plants.&lt;/p&gt;&lt;p&gt;Japanese minimalism does not involve a large number of plants, but they try to select all green design elements with taste. Bonsai is ideal here, as well as yucca or dracaena. Pots for them should be discreet, they are kept in a typical muted natural range for this interior.&lt;/p&gt;&lt;/blockquote&gt;&lt;p&gt;Familiar home flowers &mdash; &lt;a href=&quot;https://ru.wikipedia.org/wiki/%D0%A4%D0%B8%D0%B0%D0%BB%D0%BA%D0%B0&quot;&gt;violet&lt;/a&gt;, geranium or ivy, will be an excellent component of the interior in the country style. They are planted in &lt;a href=&quot;https://www.lowes.com/pl/Ceramic--Pots-planters-Planters-stands-window-boxes-Plants-planters-Lawn-garden/4294612569?refinement=4294926044&quot;&gt;ceramic pots&lt;/a&gt;. Citrus trees, mini-cypresses, as well as spicy herbs are suitable for the Mediterranean direction. Lavender in a pot will also perfectly complement the composition in the style of Provence.&lt;/p&gt;&lt;p&gt;Creating a plant composition for any interior, you should rely on your own taste, as well as on the needs of plants. For one composition, they try to select species with general care requirements. In addition, high plantings should not obscure the shallower sunlight. A thoughtful green corner, complemented by pots and planters suitable in style, can become a real highlight of any room and add beauty and comfort to the house.&lt;/p&gt;', 1, '2022-06-06 00:13:35'),
(14, 5, 4, 'How to take care of different types of plant', 'blogdecor1.jpg', '&lt;p&gt;How to take care of different types of plants&lt;/p&gt;', 1, '2022-06-06 06:32:17'),
(15, 5, 3, 'Plants', 'blog-big4.jpg', '&lt;p&gt;plants&lt;/p&gt;', 1, '2022-06-06 06:38:30');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(25) NOT NULL,
  `title` varchar(256) NOT NULL,
  `slug` varchar(256) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `img` varchar(256) NOT NULL,
  `price` int(25) NOT NULL,
  `old_price` int(25) NOT NULL,
  `content2` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `title`, `slug`, `content`, `img`, `price`, `old_price`, `content2`) VALUES
(1, 'Money Tree', 'money_tree', '<p>The succulent plant has a branched stem, which, as the plant grows, turns into a trunk, becomes woody. It has leathery, fleshy, oval leaves.</p>', 'product1.jpg', 3780, 4870, 'The Money Tree (Pachira aquatica) is a plant that has many legends and beliefs originating from China. Although there are many tales and stories as to its beginnings, the most common story is that a truck driver in Taiwan had decided to braid the trunks of five small trees in a single pot. A more legendary tale floats around of a very poor farmer who was very down on his luck and spirit. One day, he found a very curious looking plant with braided trunks. Upon inspecting the plant, he found the plant to be very hardy and resilient, and took this as a lesson that he as well should learn to be resilient and strong. From the seed of this miraculous plant, he grew more of them and sold them.'),
(2, 'Ceramic pot for plants', 'ceramic_pot_for_plants', 'The ceramic pot for plants combines elegance, simplicity and modernity, making it fit into any interior, combining different styles and preferences. Its greatest asset is the huge selection of sizes available and the whimsical color palette.', 'product2.jpg', 3500, 4750, 'Ceramic pots are sold without any drainage holes at all, which means the roots will sit in very wet conditions. If you choose to use these pots, you’ll be best off choosing a plant that can handle sitting in stagnant water—and your options will be limited. If you take care not to overwater and monitor the soil diligently, it’s certainly possible to keep houseplants in these environments. Still, you’ll save yourself a lot of trouble by opting for a pot with drainage holes.  Even with drainage holes, the glazes on ceramics will still cause these pots to retain more moisture than unpainted terracotta. The best houseplants for ceramic pots are ones that prefer evenly moist soil—generally, ones that have adapted from damper environments in nature'),
(3, 'Polyscias Fabian', 'adipiscing_cursus', 'The Polyscias Fabian is a beautiful appearance that works well in the living room or bedroom. Of course also very suitable for the office!', 'product3.jpg', 3450, 4740, 'Polyscias scutellaria \'Fabian\' (Polyscias scutellaria \'Fabian\') has luxuriant dark green, rounded leaves that are often borne on equally ornamental stems. The peculiarity and exclusivity of Poliscias \'Fabian\' gives a rare purple tint to the leaf plates.  The tree perfectly tolerates light shade, looks great in halls and office spaces. An additional effect is created by the powerful lignified trunks of Polissias \'Fabian\', looking through the dense foliage.'),
(4, 'Codiaum motley ', 'adipiscing_elit', 'Codiaum motley - perennial evergreen shrub; species of the genus Codium of the Euphorbiaceae family. Very often they are called crotons, although in reality this name refers to a different genus of plants. There is also the name \"Joseph\'s cloak\".', 'product4.jpg', 5790, 6745, 'Codiaeum variegatum (fire croton, garden croton, or variegated croton; syn. Croton variegatum L.) is a species of plant in the genus Codiaeum, which is a member of the family Euphorbiaceae. It was described by Carl Linnaeus in 1753. It is native to Indonesia, Malaysia, Australia, and the western Pacific Ocean islands, growing in open forests and scrub. The garden crotons should not be confused with Croton, a cosmopolitan genus also in the Euphorbiaceae, containing more than 700 species of herbs, shrubs and trees.'),
(5, 'Donec Eu Cook', 'donec_eu_cook', 'Donec Eu Cook - perennial evergreen shrub; species of the genus Codium of the Euphorbiaceae family. Very often they are called crotons, although in reality this name refers to a different genus of plants. There is also the name \"Joseph\'s cloak\".', 'product5.jpg', 3690, 4740, ''),
(6, 'Umbra Trigg ', 'duis_pulvinar_cook', 'Trigg is the perfect way to add some color and spice up your living space with indoor plants like small succulents, air plants, mini cacti, fake succulents, fake stonecrops, or other small plants or flowers.', 'product6.jpg', 3690, 4790, 'Designed by Moe Takemura for Umbra, Trigg is the original geometric vessel with a simple, elegant design that adds a contemporary decorative touch to any indoor space Trigg is the perfect way to add some color and liven up your living space with indoor plants such as small succulents, air plants, mini cactus, faux succulents, faux sedums or other small plants or flowers'),
(7, 'Sansevieria Zeylanica', 'eget_sagittis', 'Sansevieria Zeylanica (Sansevieria Zeylanica). Sansevieria or sansevier is sometimes called \"pike tail\" or \"mother-in-law\'s tongue.\" Sansevieria Zeilanik has beautiful wide medium-sized leaves with wavy stripes or spectacular silver-green speckles well suited for landscaping the interior of an office or home.', 'product7.jpg', 3690, 4790, 'Sansevieria zeilanika is a species or variety that is causing serious controversy today. Some consider the plant an independent species, others attribute it to varieties of the three-lane Sansevieria species. However, the battles raging among botanists do not prevent him from being one of the most beloved flower growers. Beautiful wide leaves of medium size with spectacular silver-green speckles or wavy stripes will decorate both the interior and the home floral collection. High decorativeness and unpretentiousness made the plant very popular. Sansevieria zeilanika is second in popularity only to variegated species and varieties with a yellow or white border on the leaves.'),
(8, 'Echeveria elegans', 'fringilla_augue', 'Echeveria elegans, the Mexican snow ball, Mexican gem or white Mexican rose is a species of flowering plant in the family Crassulaceae, native to semi-desert habitats in Mexico.', 'product8.jpg', 3690, 4790, 'Echeveria graceful is a thick-leaved, dense rosette of almost transparent, massive leaves. Echeveria elegans is slow growing. In adulthood, the flower reaches a maximum height of up to 20 cm and a width of up to 30 cm. Spoon-shaped leaf plates grow up to 6 cm in length and 2 cm in width, sometimes acquiring a bluish tint. The leaves are fleshy, with a waxy cuticle. Touching their surface can damage the skin and leave marks. The \"Mexican Pearl\" easily releases side arms (or babies). Often the succulent grows in dense neat clusters, forming a beautiful \"rug\".'),
(9, 'Umbra Nesta', 'gravida_semper', 'Accent your living space by bringing the outdoors in with the Nesta Planter. Its sculptural and minimal design is perfect for any modern living space. The white speckled ceramic pot can be rested inside the sculptural base at different angles to help you better show off the plants inside. If you prefer hanging plants you can easily transform Nesta into a hanging planter, it comes with an attachment that converts it from freestanding to hanging, the rope is not included. ', 'product9.jpg', 3690, 4790, 'Table planter for house plants. It consists of a stand, a suspension made of strong metal wire and a ceramic planter with a fashionable mottled pattern. Planters can be placed flat or slightly inclined on the stand to create the look you like. Place the planter on a table or hang it from the ceiling. Table stand and hanging ring included.'),
(10, 'Clusia', 'hendrerit_est', 'Clusia is an evergreen plant from the Clusia family. According to data taken from various sources, this genus unites 150-300 species, while most of them can be found in the tropical regions of South America, but they also grow in North America.', 'product10.jpg', 3690, 4790, 'Shrubs, climbing shrubs and small trees, up to 20 m tall, with evergreen foliage. Some species initially develop as epiphytes, then, increasing the root, which, sinking to the ground, taking root, suffocates the host tree. The leaves are opposite, 5-20 cm long and 5-10 cm wide, with a leathery surface, glabrous, short-petiolate. The flowers are white, greenish white, yellow or pink, with 4-9 petals. The fruit is a leathery, greenish-brown capsule that, when opened, releases several red, fleshy seeds. The species Clusia rosea is mainly cultivated. Initially, it grows as an epiphyte on large trees, after developing a root that descends to the ground, it takes root, and can destroy the host tree. Good for shaping.'),
(11, 'Aloe Brevifolia', 'jndfjnvfjaloe brevifolia', 'Aloe short-leaved is a plant from the genus Aloe of the Asphodelaceae family. The leaves are collected in a rosette, it contains 30-40 leaves. Form lanceolate, length 7-11 cm, width at the base 2.5 cm. Spots and stripes are absent. The leaves are flat below, with thorns in the upper part, the width of the leaf in the middle is 0.6-0.9 cm', 'product11.jpg', 2500, 4800, 'Aloe brevifolia is a rosette-forming succulent from South Africa with rosettes of gray leaves that grow on top of each other to form a clump about 1 foot high. Each rosette is just over 3 inches wide, bearing broad, triangular, thick, pale gray leaves with white thorns along the margins and a few along the keel of the undersurface. In late spring inflorescences of orange tubular flowers appear in unbranched spikes 16 to 24 inches high. Plant in full sun in well-drained soil. Water only occasionally - this is a drought tolerant Mediterranean climate plant. Proven endurance up to 25 degrees Fahrenheit, but not considered much more hardy than that. It is a large, small scale ground cover aloe that was one of the first aloe successfully grown in Europe and received the Royal Horticultural Society\'s Award of Garden Merit in 2002.'),
(12, 'Echeveria agavoides', 'Echeveria agavoides', 'Echeveria agavoides, or lipstick echeveria, is a species of flowering plant in the family Crassulaceae, native to rocky areas of Mexico, notably the states of San Luis Potosí, Hidalgo, Guanajuato and Durango.', 'product12.jpg', 2500, 3800, 'Echeveria agave is a succulent bushy plant with a very short or no stem at all, on which dense rosettes of light green leaves with a red tint are formed. Triangular-oval leaves, 3-9 cm long and 5-6 cm wide, covered with a waxy coating, pointed at the tips and with translucent edges. In late spring - early summer, Echeveria agave appears a lot of red-yellow round-bell-shaped flowers, up to 1.5 cm long, collected in apical inflorescences 30-40 cm high, appearing from the very middle of the rosettes.');

-- --------------------------------------------------------

--
-- Структура таблицы `topics`
--

CREATE TABLE `topics` (
  `id` int(25) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `topics`
--

INSERT INTO `topics` (`id`, `name`, `description`) VALUES
(3, 'Plant', '<p>plant</p>'),
(4, 'Decor', '<p>decor</p>'),
(6, 'Ecommerce', ''),
(7, 'Service', '<p>service</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(25) NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `admin`, `username`, `email`, `password`, `created_at`) VALUES
(4, 1, 'kolk', 'f@gmail.com', '$2y$10$agYH4vrDxP38iwWT41A0reTwQ1RPfn8QrULR5FhASDcsX1vQc5hGO', '2022-05-22 10:50:33'),
(5, 1, '123', 'f@gmail.com', '$2y$10$wLQ9vnbpwWCvBLdWauUcKu.N9Rh8/e98vXajAMsA4c8Pe0FHDFtlu', '2022-05-22 21:40:43'),
(6, 1, 'hbhf', 'fff@gmail.com', '$2y$10$qrCzg3n0JEEUQzvp8/pRVeAFH.8mUa5ZIR99Ihvo6thF5umELzKom', '2022-05-23 02:59:08'),
(7, 1, 'dd', 'df@gmail.com', '$2y$10$NuujFU7914Y27nAYV22aUuB1auKVdChRj1TS1Yff4CfsHNf/Jb5FK', '2022-05-23 03:01:45'),
(8, 1, 'kolkanat', 'f@gmail.com', '$2y$10$zQx8Qc/TCw.JXojCVQubVeLPCzzLKcKVysMs7/tFBcUy417Hw5jym', '2022-05-23 03:06:42'),
(9, 1, 'dddddddd', 'f@gmail.com', '$2y$10$LEzQD6h8HtFLAna/72IgTOgC7/VoaoNOUzLTCRev.cng8PyIHtMiq', '2022-05-23 07:03:53'),
(10, 0, 'Kolkanat', 'kolkanat@gmail.com', '$2y$10$Bvz6jsxGwCSX.Hy5dxCKgOrl.aBo9pOyG6FFjAaAbv2djmqLuM2Ra', '2022-06-06 00:00:13'),
(11, 0, 'Kolkanat', 'kolkanat@gmail.com', '$2y$10$IexUt8uBMUUtIM8QHtEunOD.6hijQpa2YQ5NrQetZ0/KR.FzTYVOi', '2022-06-06 00:13:06'),
(12, 1, 'kolkanat', 'kolkanat@gmail.com', '$2y$10$Y/k.0MzEk.dihEqF6Ovv2OGwYHYmiPjpTsIqi4H6sTx20hZWdgZ8G', '2022-06-06 00:17:15'),
(13, 0, 'Kolkanat', 'kolkanat@gmail.com', '$2y$10$Pii5NnTyz9B/9bs6YDJRou2ab/0muWP1DmHjAy6rYWzESfeZCjRWW', '2022-06-06 00:27:36');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `feedback_blog`
--
ALTER TABLE `feedback_blog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Индексы таблицы `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT для таблицы `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `feedback_blog`
--
ALTER TABLE `feedback_blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
