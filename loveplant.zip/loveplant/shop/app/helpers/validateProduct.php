<?php


function validateProduct($post)
{
    $errors = array();

    if (empty($post['title'])) {
        array_push($errors, 'Title is required');
    }

    if (empty($post['slug'])) {
        array_push($errors, 'slug is required');
    }

    if (empty($post['content'])) {
        array_push($errors, 'Content is required');
    }

    if (empty($post['price'])) {
        array_push($errors, 'Price is required');
    }
    if (empty($post['old_price'])) {
        array_push($errors, 'Old price is required');
    }



    return $errors;
}