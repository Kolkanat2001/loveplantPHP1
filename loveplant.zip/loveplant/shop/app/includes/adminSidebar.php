<div class="left-sidebar" style="background: #10672a; ">
    <ul>
        <li><a href="/shop/admin/posts/index.php">Manage Posts</a></li>
        <li><a href="/shop/admin/users/index.php">Manage Users</a></li>
        <li><a href="/shop/admin/topics/index.php">Manage Topics</a></li>
        <li><a href="/shop/admin/products/index.php">Manage Products</a></li>
    </ul>
</div>