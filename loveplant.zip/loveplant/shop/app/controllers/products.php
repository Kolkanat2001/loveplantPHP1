<?php

include(ROOT_PATH . "/app/database/db.php");
include(ROOT_PATH . "/app/helpers/middleware.php");
include(ROOT_PATH . "/app/helpers/validateProduct.php");

$table = 'products';

$products = selectAll($table);


$errors = array();
$id = "";
$title = "";
$slug = "";
$content = "";
$price = "";
$old_price = "";

if (isset($_GET['id'])) {
    $product = selectOne($table, ['id' => $_GET['id']]);

    $id = $product['id'];
    $title = $product['title'];
    $slug = $product['slug'];
    $content = $product['content'];
    $price = $product['price'];
    $old_price = $product['old_price'];
}

if (isset($_GET['delete_id'])) {
    adminOnly();
    $count = delete($table, $_GET['delete_id']);
    $_SESSION['message'] = "Product deleted successfully";
    $_SESSION['type'] = "success";
    header("location: " . BASE_URL . "./index.php");
    exit();
}





if (isset($_POST['add-product'])) {
    adminOnly();
    $errors = validateProduct($_POST);

    if (!empty($_FILES['img']['name'])) {
        $image_name =  $_FILES['img']['name'];
        $destination = ROOT_PATH . "/assets/images/" . $image_name;

        $result = move_uploaded_file($_FILES['img']['tmp_name'], $destination);

        if ($result) {
            $_POST['img'] = $image_name;
        } else {
            array_push($errors, "Failed to upload image");
        }
    } else {
        array_push($errors, "Product image required");
    }
    if (count($errors) == 0) {
        $id = $_POST['id'];
        unset($_POST['add-product']);
        $_POST['content'] = htmlentities($_POST['content']);

        $product_id = create($table, $_POST);
        $_SESSION['message'] = "Product created successfully";
        $_SESSION['type'] = "success";
        header("location: " . BASE_URL . "/shop.php");
        exit();
    } else {
        $title = $_POST['title'];
        $slug = $_POST['slug'];
        $content = $_POST['content'];
        $price = $_POST['price'];
        $old_price = $_POST['old_price'];
    }
}


if (isset($_POST['update-product'])) {
    adminOnly();
    $errors = validateProduct($_POST);

    if (!empty($_FILES['img']['name'])) {
        $img_name = $_FILES['img']['name'];
        $destination = ROOT_PATH . "/assets/images/" . $img_name;

        $result = move_uploaded_file($_FILES['img']['tmp_name'], $destination);

        if ($result) {
            $_POST['img'] = $img_name;
        } else {
            array_push($errors, "Failed to upload image");
        }
    } else {
        array_push($errors, "Product image required");
    }

    if (count($errors) == 0) {
        $id = $_POST['id'];
        unset($_POST['update-product'], $_POST['id']);


        $product_id = update($table, $id, $_POST);
        $_SESSION['message'] = "Products updated successfully";
        $_SESSION['type'] = "success";
        header("location: " . BASE_URL . "/shop.php");
    } else {
        $title = $_POST['title'];
        $slug = $_POST['slug'];
        $content = $_POST['content'];
        $price = $_POST['price'];
        $old_price = $_POST['old_price'];
    }

}