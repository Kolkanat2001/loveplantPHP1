<?php session_start();?>
<!DOCTYPE html>
<?php
include("shop/path.php");

include (ROOT_PATH . "/app/controllers/posts.php");
if (isset($_GET['id'])) {
    $post = selectOne('posts', ['id' => $_GET['id']]);
}
$topics = selectAll('topics');
$posts = selectAll('posts', ['published' => 1]);

if (isset($_GET['t_id'])) {
    $posts = getPostsByTopicId($_GET['t_id']);
    $postsTitle = "You searched for posts under '" . $_GET['name'] . "'";
} else if (isset($_POST['search-term'])) {
    $postsTitle = "You searched for '" . $_POST['search-term'] . "'";
    $posts = searchPosts($_POST['search-term']);
} else {
    $posts1 = getPublishedPosts();
}

session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$review = get_reviews_blog();
function validate_input($input)
{
    $input = stripslashes(trim($input));
    $input = htmlentities($input, ENT_QUOTES);
    return $input;
}
if(isset($_POST['submit']))
{
    if(isset($_POST['comment'],$_POST['name'],$_POST['email']) && !empty($_POST['comment']) && !empty($_POST['name']) && !empty($_POST['email']))
    {
        $Comment = $_POST['comment'];

        if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
        {
            $errorMsg[] = 'Please enter valid email address';
        }
        else
        {
            //validate_input is a custom function
            $Comment = validate_input($_POST['comment']);
            $Name   = validate_input($_POST['name']);
            $email  = validate_input($_POST['email']);


            $host = 'localhost';
            $db = 'love_plant';
            $user = 'root';
            $pass = '';
            $charset = 'utf8';

            $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
            $opt = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            $pdo = new PDO($dsn, $user, $pass, $opt);



            $sql = 'insert into love_plant.feedback_blog (comment,name, email, p_id, created_at, updated_at) values (:comment, :name, :email, :p_id,:created_at, :updated_at)';
            $statement = $pdo->prepare($sql);

            $params = [
                'comment' => $Comment,
                'name' => $Name,
                'email' => $email,
                'p_id' => $_GET['id'],
                'created_at'=> date('Y-m-d H:i:s'),
                'updated_at'=> date('Y-m-d H:i:s')
            ];

            $statement->execute($params);

        }$id=$_GET['id'];
        echo '<script>window.location="blog-details.php?id='.$_GET['id'].'"</script>';
    }
}

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - blog details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->
<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li>blog details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--blog body area start-->
<div class="blog_details">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <!--blog grid area start-->
                <div class="blog_wrapper blog_wrapper_details">
                    <article class="single_blog">
                        <figure>
                            <div class="post_header">
                                <h3 class="post_title"><?php echo $post['title']; ?></h3>
                                <div class="blog_meta">

                                    <p>     On : <a href="#"><?php echo date('F j, Y', strtotime($post['created_at'])); ?></a>
                                </div>
                            </div>
                            <div class="blog_thumb">
                                <a href="#"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                            </div>
                            <figcaption class="blog_content">
                                <div class="post_content">
                                    <?php echo html_entity_decode($post['body']);?>
                                </div>
                                <div class="entry_content">
                                    <div class="post_meta">

                                    </div>

                                    <div class="social_sharing">
                                        <p>share this post:</p>
                                        <ul>
                                            <li><a href="#" title="facebook"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#" title="twitter"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#" title="pinterest"><i class="fa fa-pinterest"></i></a>
                                            </li>
                                            <li><a href="#" title="google+"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li><a href="#" title="linkedin"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </figcaption>
                        </figure>
                    </article>
                    <div class="related_posts">
                        <h3>Related posts</h3>
                        <div class="row">
                            <?php
                            include ('inc/db.php');
                            $query=$pdo->prepare("select *from love_plant.posts LIMIT 3");
                            $query->execute();

                            while($post=$query->fetch()): ?>
                            <div class="col-lg-4 col-md-6">
                                <article class="single_related">
                                    <figure>
                                        <div class="related_thumb">
                                            <a href="blog-details.php?id=<?php echo $post['id']; ?>"><img src="assets/img/blog/<?php echo $post['image']; ?>"
                                                                             alt=""></a>
                                        </div>
                                        <figcaption class="related_content">
                                            <h4><a href="blog-details.php?id=<?php echo $post['id']; ?>"><?php echo $post['title']; ?></a></h4>
                                            <div class="blog_meta">
                                                <span class="author"> <a href="#"><?php echo $post['username']; ?></a>  </span>
                                                <span class="meta_date"> <?php echo date('F j, Y', strtotime($post['created_at'])); ?> </span>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                            <?php endwhile;?>
                        </div>
                    </div>
                    <div class="comments_box">
                        <h3> Comments </h3>
                        <?php if (!empty($review)): ?>
                        <?php foreach ($review as $p): ?>
                        <?php if (($_GET['id'])==$p['p_id']): ?>
                        <div class="comment_list">
                            <div class="comment_thumb">
                                <img src="assets/img/blog/comment2.png.jpg" alt="">
                            </div>
                            <div class="comment_content">
                                <div class="comment_meta">
                                    <h5><a href="#"><?= $p['name']?></a></h5>
                                    <span><?= $p['created_at']?></span>
                                </div>
                                <p><?= $p['comment']?></p>

                            </div>

                        </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>

                    </div>

                    <div class="comments_form">
                        <h3>Leave a Reply </
                        <p>Your email address will not be published. Required fields are marked *</p>
                        <form action="#">
                            <div class="row">
                                <div class="col-12">
                                    <label for="review_comment">Comment </label>
                                    <textarea formmethod="post" id="Comment" name="comment" placeholder="" id="review_comment"></textarea>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="author">Name</label>
                                    <input formmethod="post" id="Name" name="name" type="text" placeholder="<?php echo $_SESSION['username']; ?>" value="<?php echo $_SESSION['username']; ?>">

                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="email">Email </label>
                                    <input formmethod="post" name="email" id="email" type="text">
                                </div>

                            </div>
                            <button class="button" type="submit" formmethod="post" name="submit" value="submit">Post Comment</button>
                        </form>
                    </div>

                </div>
                <!--blog grid area start-->
            </div>
            <div class="col-lg-3 col-md-12">
                <div class="blog_sidebar_widget">
                    <div class="widget_list widget_search">
                        <div class="widget_title">
                            <h3>Search</h3>
                        </div>
                        <form action="#">
                            <input placeholder="Search..." type="text">
                            <button type="submit">search</button>
                        </form>
                    </div>
                    <div class="widget_list comments">
                        <div class="widget_title">
                            <h3>Recent Comments</h3>
                        </div>
                        <?php
                        include ('inc/db.php');

                        $query=$pdo->prepare("select *from love_plant.feedback_blog LIMIT 0,4");
                        $query->execute();

                        while($r=$query->fetch()):?>
                            <div class="post_wrapper">
                                <div class="post_thumb">
                                    <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                                </div>
                                <div class="post_info">
                                    <span> <a href="#"><?= $r['name']?></a> says:</span>
                                    <a href="blog-details.html"><?= $r['comment']?></a>
                                </div>
                            </div>

                        <?php endwhile;?>
                    </div>
                    <div class="widget_list widget_post">
                        <div class="widget_title">
                            <h3>Recent Posts</h3>
                        </div>
                        <?php foreach ($posts as $post): ?>
                            <div class="post_wrapper">
                                <div class="post_thumb">
                                    <a href="blog-details.html"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                                </div>
                                <div class="post_info">
                                    <h4><a href="blog-details.html"><?php echo html_entity_decode(substr($post['title'], 0, 20) . '...'); ?></a></h4>
                                    <span><?php echo date('F j, Y', strtotime($post['created_at'])); ?> </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="widget_list widget_categories">
                        <div class="widget_title">

                            <h3>Categories</h3>
                        </div>
                        <ul>
                            <?php foreach ($topics as $key => $topic): ?>
                                <li><a href="#"><?php echo $topic['name']; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--blog section area end-->


<!--brand area start-->
<div class="brand_area color_five">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>
