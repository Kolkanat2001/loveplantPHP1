<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - cart page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>


<!--header area start-->
<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Cart</h3>
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li>Shopping Cart</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--shopping cart area start -->
<div class="shopping_cart_area mt-100" >
    <div class="container">
        <form action="#">
            <div class="row">
                <div class="col-12">
                    <div class="table_desc" id="mini-cart">
                        <div class="cart_page table-responsive">
                            <?php if (!empty($_SESSION['cart'])): ?>
                            <table>
                                <thead>
                                <tr>

                                    <th class="product_thumb">Image</th>
                                    <th class="product_name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product_quantity">Quantity</th>
                                    <th class="product_total">Total</th>
                                    <th class="product_total">Delete</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $totalCounter = 0;
                                $itemCounter = 0;
                                foreach ($_SESSION['cart'] as $id => $item):

                                $total = $item['price'] * $item['qty'];
                                $totalCounter+= $total;
                                $itemCounter+=$item['qty'];


                                ?>
                                <tr>

                                    <td class="product_thumb"><a href="#"><img
                                                src="assets/img/product/<?= $item['img'] ?>" alt="<?= $item['title'] ?>"></a></td>
                                    <td class="product_name"><a href="#"><?= $item['title'] ?></a></td>
                                    <td class="product-price" ><input type="hidden" class="upprice" value="<?= $item['price'] ?>"><?= $item['price'] ?></td>
                                    <td class="product_quantity"><input type='number'  name='upqty' data-item-id="<?php echo $id?>" onchange="subTotal()" class="upqty" min="1" max="100" value='<?= $item['qty'] ?>'></td>

                                    <td class="product_totals"><?= $total ?> </td>
                                    <td class="product_delete"><a href="shop.php?action=delete&id=<?= $item["id"]; ?>"><i class="icon-x"></i></a> </td>
                                    <?php endforeach; ?>

                                </tr>


                                </tbody>
                            </table>
                            <?php else: ?>
                                <p>Cart's empty...</p>
                            <?php endif; ?>
                        </div>
                        <div class="cart_submit">
                            <button type="submit" href="cart.php?action=update-qty">update cart</button>
                            <?php if (!empty($_SESSION['cart'])): ?>
                            <button type="button" id="clear-cart"><a href="cart.php?action=clear&id=<?= $item["id"]; ?>">Clear</a></button>

                        </div>

                    </div>
                </div>
            </div>

            <!--coupon code area start-->
            <div class="coupon_area">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code left">
                            <h3>Coupon</h3>
                            <div class="coupon_inner">
                                <p>Enter your coupon code if you have one.</p>
                                <input placeholder="Coupon code" type="text">
                                <button type="submit">Apply coupon</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="coupon_code right">
                            <h3 >Cart Totals</h3>
                            <div class="coupon_inner">
                                <div class="cart_subtotal">
                                    <p>Subtotal</p>
                                    <p class="cart_amount qtotal" id="qtotal"><?= $totalCounter?>₸</p>
                                </div>
                                <div class="cart_subtotal ">
                                    <p>Quantity</p>
                                    <p class="cart_amount"><span id="modal-cart-qty"><?= ($itemCounter==0)?$itemCounter.' item':$itemCounter.' '; ?></span></p>
                                </div>


                                <div class="cart_subtotal">
                                    <p>Total</p>
                                    <p class="cart_amount"><?= $totalCounter ?>₸</p>
                                </div>
                                <div class="checkout_btn">

                                       <a href="checkout.php">Checkout  </a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area end-->
        </form>
    </div>
</div>
<?php endif;?>
<!--shopping cart area end -->
<script>

    var qt=0
    var upprice=document.getElementsByClassName('upprice');
    var upqty=document.getElementsByClassName('upqty');
    var product_total=document.getElementsByClassName('product_totals');
    var qtotal=document.getElementsByClassName('qtotal');

    function subTotal() {
        qt=0
        for (i = 0; i < upprice.length; i++) {
            product_total[i].innerText = (upprice[i].value) * (upqty[i].value);
            qt=qt+ (upprice[i].value) * (upqty[i].value);
        }
        qtotal.innerText=qt;
    }
    subTotal();

</script>
<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->

<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>