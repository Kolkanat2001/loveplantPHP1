<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();

function pre($array){
    echo "<pre>";
    print_r($array);
    echo "</pre>";
}

function validate_input($input){
    $input = stripslashes(trim($input));
    $input = htmlentities($input,ENT_QUOTES);
    return $input;
}

if(isset($_POST['submit']))
{
    if(isset($_POST['first_name'],$_POST['last_name'],$_POST['city'],$_POST['address'], $_POST['phone'], $_POST['email']) && !empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['city']) && !empty($_POST['address']) &&  !empty($_POST['phone']) && !empty($_POST['email'])   )
    {
        $firstName = $_POST['first_name'];

        if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
        {
            $errorMsg[] = 'Please enter valid email address';
        }
        else
        {
            //validate_input is a custom function
            //you can find it in helpers.php file
            $firstName  = validate_input($_POST['first_name']);
            $lastName   = validate_input($_POST['last_name']);
            $city       = validate_input($_POST['city']);
            $address    = validate_input($_POST['address']);
            $address2   = (!empty($_POST['address'])?validate_input($_POST['address']):'');

            $phone      = validate_input($_POST['phone']);
            $email      = validate_input($_POST['email']);


            $host = 'localhost';
            $db = 'love_plant';
            $user = 'root';
            $pass = '';
            $charset = 'utf8';

            $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
            $opt = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];
            $pdo = new PDO($dsn, $user, $pass, $opt);



            $sql = 'insert into love_plant.checkout (first_name, last_name, city, address, address2, phone, email,  order_status,created_at, updated_at) values (:fname, :lname, :city,  :address, :address2, :phone,:email,   :order_status,:created_at, :updated_at)';
            $statement = $pdo->prepare($sql);
            $params = [
                'fname' => $firstName,
                'lname' => $lastName,
                'city' => $city,
                'address' => $address,
                'address2' => $address2,
                'phone' => $phone,
                'email' => $email,
                'order_status' => 'confirmed',
                'created_at'=> date('Y-m-d H:i:s'),
                'updated_at'=> date('Y-m-d H:i:s')
            ];

            $statement->execute($params);
            if($statement->rowCount() == 1)
            {

                $getOrderID = $pdo->lastInsertId();

                if(isset($_SESSION['cart']) || !empty($_SESSION['cart']))
                {
                    $sqlDetails = 'insert into love_plant.order_details (order_id, product_id, title, price, qty, total_price) values(:order_id,:product_id,:title,:price,:qty,:total_price)';
                    $orderDetailStmt = $pdo->prepare($sqlDetails);

                    $totalPrice = 0;
                    foreach($_SESSION['cart'] as $item)
                    {
                        $total=$item['price']*$item['qty'];
                        $totalPrice+=$total;

                        $paramOrderDetails = [
                            'order_id' =>  $getOrderID,
                            'product_id' =>  $item['product_id'],
                            'title' =>  $item['title'],
                            'price' =>  $item['price'],
                            'qty' =>  $item['qty'],
                            'total_price' =>  $totalPrice
                        ];

                        $orderDetailStmt->execute( $paramOrderDetails);
                    }

                    $updateSql = 'update love_plant.checkout set total_price = :total where id = :id';

                    $rs = $pdo->prepare($updateSql);
                    $prepareUpdate = [
                        'total' => $totalPrice,
                        'id' =>$getOrderID
                    ];

                    $rs->execute($prepareUpdate);

                    unset($_SESSION['cart']);
                    $_SESSION['confirm_order'] = true;
                    echo '<script>window.location="thank-you.php"</script>';
                    exit();
                }
            }
            else
            {
                $errorMsg[] = 'Unable to save your order. Please try again';
            }
        }
    }
    else
    {
        $errorMsg = [];

        if(!isset($_POST['first_name']) || empty($_POST['first_name']))
        {
            $errorMsg[] = 'First name is required';
        }
        else
        {
            $fnameValue = $_POST['first_name'];
        }

        if(!isset($_POST['last_name']) || empty($_POST['last_name']))
        {
            $errorMsg[] = 'Last name is required';
        }
        else
        {
            $lnameValue = $_POST['last_name'];
        }

        if(!isset($_POST['city']) || empty($_POST['city']))
        {
            $errorMsg[] = 'City is required';
        }
        else
        {
            $cityValue = $_POST['city'];
        }

        if(!isset($_POST['phone']) || empty($_POST['phone']))
        {
            $errorMsg[] = 'Phone is required';
        }
        else
        {
            $phoneValue = $_POST['phone'];
        }
        if(!isset($_POST['email']) || empty($_POST['email']))
        {
            $errorMsg[] = 'Email is required';
        }
        else
        {
            $emailValue = $_POST['email'];
        }

        if(!isset($_POST['address']) || empty($_POST['address']))
        {
            $errorMsg[] = 'Address is required';
        }
        else
        {
            $addressValue = $_POST['address'];
        }




        if(isset($_POST['address2']) || !empty($_POST['address2']))
        {
            $address2Value = $_POST['address2'];
        }

    }
}
?>

<?php
require 'paypal/config.php';

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>Love & Plant - checkout page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="/assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="/assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="/assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="/assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="/assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="/assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="/assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="/assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="/assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!--modernizr min js here-->
    <script src="/assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3></h3>
                    <ul>
                        <li><a href="index.php">home</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<?php
if(!empty($_GET['paymentID']) && !empty($_GET['payerID']) && !empty($_GET['token']) && !empty($_GET['pid']) ){
    $paymentID = $_GET['paymentID'];
    $payerID = $_GET['payerID'];
    $token = $_GET['token'];
    $pid = $_GET['pid'];

    $host = 'localhost';
    $db = 'love_plant';
    $user = 'root';
    $pass = '';
    $charset = 'utf8';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $opt = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    $pdo = new PDO($dsn, $user, $pass, $opt);



    $sql1 = 'insert into love_plant.orders ( payerID, paymentID, token, pid, user_id ) VALUES (:payerID, :paymentID, :token, :pid, :user_id)';
    $statement = $pdo->prepare($sql1);
    $params = [
        'paymentID' => $paymentID,
        'payerID' => $payerID,
        'token' => $token,
        'pid' => $pid,
        'user_id' => $_SESSION['id']

    ];

    $statement->execute($params);
    ?>
    <div class="alert alert-success">
        <strong>Success!</strong> Your order processed successfully.
    </div>
    <table>
        <tr>
            <td>Payment Id:  <?php echo $paymentID; ?></td>
        </tr>
        <tr>
            <td>Payer Id: <?php echo $payerID; ?></td>
        </tr>

        <tr>
            <td>token: <?php echo $token; ?></td>
        </tr>
    </table>
    <div class="row">
        <div class="col-md-12" >


                <?php unset($_SESSION['cart']);?>

        </div>
    </div>
    <?php
}
?>
<!--footer area start-->
<?php include("assets/layouts/js.php") ?>
<!--footer area end-->

<?php include("assets/layouts/footer.php") ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>





</body>

</html>
