<?php
error_reporting(-1);
session_start();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - contact page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS 
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>Contact Us</h3>
                    <ul>
                        <li><a href="index.html">home</a></li>
                        <li>contact us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--contact map start-->
<center>
    <div class="contact_map mt-100">
        <div class="map-area">
            <div id="googleMap">
                <iframe src="https://www.google.com/maps/d/embed?mid=1HHIguoinsOdKHv8Q9DGeSjg6mFynQXuu&ll=43.23514639999997%2C76.9097448&z=17" width="640" height="480" ></iframe></div>


        </div>
    </div>
</center>
<!--contact map end-->

<!--contact area start-->
<div class="contact_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="contact_message content">
                    <h3>contact us</h3>
                    <p>Our plants are sourced from local growers to ensure the highest quality and to
                        support family-owned businesses. In-store inventory and pricing
                        can differ by shop location, and from our online offerings.</p>
                    <ul>
                        <li><i class="fa fa-fax"></i> Address : Manasa 123</li>
                        <li><i class="fa fa-phone"></i> <a href="#">love_plant@gmail.com</a></li>
                        <li><i class="fa fa-phone"></i> <a href="#">t.me</a></li>
                        <li><i class="fa fa-envelope-o"></i><a href="tel:87472454517">87472454517</a> </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="contact_message form">
                    <h3>Tell us your project</h3>
                    <form id="contact-form" method="POST" action="#" class="form-signin">

                        <?php if(isset($smsg)){ ?> <div class="alert alert-success" role="alert"><?php echo $smsg; ?> </div><?php }?>
                        <?php if(isset($fsmsg)){ ?> <div class="alert alert-danger" role="alert"><?php echo $fsmsg; ?> </div><?php }?>
                        <p>
                            <label> Your Name (required)</label>
                            <input name="Name" value="<?= $_SESSION['username']?>" type="text">
                        </p>
                        <p>
                            <label> Your Email (required)</label>
                            <input name="Email" placeholder="Email *" type="email">
                        </p>
                        <p>
                            <label> Subject</label>
                            <input name="Subject" placeholder="Subject *" type="text">
                        </p>
                        <div class="contact_textarea">
                            <label> Your Message</label>
                            <textarea placeholder="Message *" name="Message" class="form-control2"></textarea>
                        </div>
                        <button type="submit"> Send</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<!--contact area end-->
<?php
require("connect.php");

if(isset($_POST['Name']) && isset($_POST['Email']) && isset($_POST['Subject']) && isset($_POST['Message'])){
    $name= $_POST['Name'];
    $email=$_POST['Email'];
    $subject=$_POST['Subject'];
    $message=$_POST['Message'];



    $query="INSERT INTO contact (Name, Email, Subject, Message) VALUES ('$name','$email','$subject','$message')";
    $result=mysqli_query($connection,$query);

    if ($result) {
        $smsg= "Message sent";
    }else{
        $fsmsg= "Error";
    }
}
?>

<!--footer area start-->
<?php include ("assets/layouts/footer.php")?>
<!--footer area end-->



<!-- JS
============================================ -->

<!--map js code here-->
<script
    src="https://maps.google.com/maps/api/js?sensor=false&amp;libraries=geometry&amp;v=3.22&amp;key=AIzaSyChs2QWiAhnzz0a4OEhzqCXwx_qA9ST_lE"></script>
<script src="https://www.google.com/jsapi"></script>
<script src="assets/js/map.js"></script>

<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>