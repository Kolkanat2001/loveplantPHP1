<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant - about us</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--modernizr min js here-->
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

</head>

<body>

<!--header area start-->

<?php include('assets/layouts/header.php');?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3>About Us</h3>
                    <ul>
                        <li><a href="index.php">home</a></li>
                        <li>about us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->

<!--about section area -->
<section class="about_section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <figure>
                    <div class="about_thumb">
                        <img src="assets/img/about/about1.jpg" alt="">
                    </div>
                    <figcaption class="about_content">
                        <h1>We are a company that sells indoor plants and indoor decoration.</h1>
                        <p>Green plants create conditions on Earth for the existence of all living organisms.
                            They release oxygen, which is necessary for respiration. Covering the Earth with a green carpet,
                            the plants protect and preserve it. Thickets of plants create their own climate,
                            softer and more humid, because the foliage resists the drying effect of the sun's rays.</p>
                        <div class="about_signature">
                            <img src="assets/img/about/about-us-signature.png" alt="">
                        </div>
                    </figcaption>
                </figure>
            </div>
        </div>
    </div>
</section>
<!--about section end-->

<!--chose us area start-->
<div class="choseus_area" data-bgimg="assets/img/about/about-us-policy-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <div class="single_chose">
                    <div class="chose_icone">
                        <img src="assets/img/about/About_icon1.png" alt="">
                    </div>
                    <div class="chose_content">
                        <h3>Creative Design</h3>
                        <p>We try to make the decoration with tastes and so that you and the plant feel comfortable.</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="single_chose">
                    <div class="chose_icone">
                        <img src="assets/img/about/About_icon2.png" alt="">
                    </div>
                    <div class="chose_content">
                        <h3>Affordable prices</h3>
                        <p>We offer our clients affordable prices for a plant, decoration and service.</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="single_chose">
                    <div class="chose_icone">
                        <img src="assets/img/about/About_icon3.png" alt="">
                    </div>
                    <div class="chose_content">
                        <h3>Online Support 24/7</h3>
                        <p>We offer 24/7 support, we will help you give advice and solve the problem.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--chose us area end-->

<!--services img area-->
<div class="about_gallery_section">
    <div class="container">
        <div class="about_gallery_container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <article class="single_gallery_section">
                        <figure>
                            <div class="gallery_thumb">
                                <img src="assets/img/about/about2.jpg" alt="">
                            </div>
                            <figcaption class="about_gallery_content">
                                <h3>What do we do?</h3>
                                <p>We are online store of houseplants. On our site you can grow
                                    a plant at your own discretion, as well as learn how to take care of them.
                                    We hope that you will learn a lot of interesting things from our site.</p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4 col-md-4">
                    <article class="single_gallery_section">
                        <figure>
                            <div class="gallery_thumb">
                                <img src="assets/img/about/about3.jpg" alt="">
                            </div>
                            <figcaption class="about_gallery_content">
                                <h3>Our Mission</h3>
                                <p>Plants make us happier, healthier, more efficient and boost our creativity.
                                    But all our modern city-living has us indoors a lot.
                                    Our mission is to give people a smile, good mood and even health through indoor plants. </p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <div class="col-lg-4 col-md-4">
                    <article class="single_gallery_section">
                        <figure>
                            <div class="gallery_thumb">
                                <img src="assets/img/about/about4.jpg" alt="">
                            </div>
                            <figcaption class="about_gallery_content">
                                <h3>History Of Us</h3>
                                <p>This project began with the need to make a website. We thought about what
                                    to choose and I chose the sale of plants as a project.
                                    We realized that
                                    this was a good idea for an online store. Over time,
                                    I put together a team and we began to develop this project.</p>
                            </figcaption>
                        </figure>
                    </article>
                </div>
            </div>
        </div>
    </div>
</div>
<!--services img end-->

<!--testimonial area start-->
<div class="faq-client-say-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="faq-client_title">
                    <h2>What can we do for you ?</h2>
                </div>
                <div class="faq-style-wrap" id="faq-five">
                    <!-- Panel-default -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a id="octagon" class="collapsed" role="button" data-toggle="collapse"
                                   data-target="#faq-collapse1" aria-expanded="true" aria-controls="faq-collapse1">
                                    <span class="button-faq"></span>Fast Free Delivery</a>
                            </h5>
                        </div>
                        <div id="faq-collapse1" class="collapse show" aria-expanded="true" role="tabpanel"
                             data-parent="#faq-five">
                            <div class="panel-body">
                                <p>About fast free delivery option</p>
                                <p>If you order a certain number of plants, we will deliver you free of charge
                                </p>
                                <p> If you order a certain number of plants, we will deliver you free of charge
                                    Also, if you use our package, the delivery will also be free.</p>
                            </div>
                        </div>
                    </div>
                    <!--// Panel-default -->

                    <!-- Panel-default -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse"
                                   data-target="#faq-collapse2" aria-expanded="false"
                                   aria-controls="faq-collapse2"> <span class="button-faq"></span>Company with uniqe idea with houseplants</a>
                            </h5>
                        </div>
                        <div id="faq-collapse2" class="collapse" aria-expanded="false" role="tabpanel"
                             data-parent="#faq-five">
                            <div class="panel-body">
                                <p>Nam liber tempor cum soluta nobis eleifend option.</p>
                                <p>If you order a certain number of plants, we will deliver you free of charge
                                </p>
                                <p> If you order a certain number of plants, we will deliver you free of charge
                                    Also, if you use our package, the delivery will also be free.</p>
                            </div>
                        </div>
                    </div>
                    <!--// Panel-default -->

                    <!-- Panel-default -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse"
                                   data-target="#faq-collapse3" aria-expanded="false"
                                   aria-controls="faq-collapse3"> <span class="button-faq"></span>Green office design</a>
                            </h5>
                        </div>
                        <div id="faq-collapse3" class="collapse" role="tabpanel" data-parent="#faq-five">
                            <div class="panel-body">
                                <p>Nam liber tempor cum soluta nobis eleifend option.</p>
                                <p>Congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non
                                    habent claritatem insitam est usus legentis in iis qui facit eorum claritatem.
                                    Investigationes demonstraverunt lectores legere me.
                                </p>
                                <p> Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium
                                    lectorum.</p>
                            </div>
                        </div>
                    </div>
                    <!--// Panel-default -->

                    <!-- Panel-default -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse"
                                   data-target="#faq-collapse4" aria-expanded="false"
                                   aria-controls="faq-collapse4"> <span class="button-faq"></span>Best Shopping
                                    Strategies</a>
                            </h5>
                        </div>
                        <div id="faq-collapse4" class="collapse" role="tabpanel" data-parent="#faq-five">
                            <div class="panel-body">
                                <p>Nam liber tempor cum soluta nobis eleifend option.</p>
                                <p>Congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non
                                    habent claritatem insitam est usus legentis in iis qui facit eorum claritatem.
                                    Investigationes demonstraverunt lectores legere me.
                                </p>
                                <p> Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium
                                    lectorum.</p>
                            </div>
                        </div>
                    </div>
                    <!--// Panel-default -->
                </div>

            </div>
            <div class="col-lg-6 col-md-6">
                <!--testimonial area start-->
                <div class="testimonial_area  testimonial_about">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="section_title">
                                    <h2>What Our Customers Says ?</h2>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial_container">
                            <div class="row">
                                <div class="testimonial_carousel owl-carousel">
                                    <div class="col-12">
                                        <div class="single-testimonial">
                                            <div class="testimonial-icon-img">
                                                <img src="assets/img/about/testimonials-icon.png" alt="">
                                            </div>
                                            <div class="testimonial_content">
                                                <p>“ When a beautiful design is combined with powerful technology,
                                                    <br>
                                                    it truly is an artwork. I love how my website operates and looks
                                                    with this theme. Thank you for the awesome product. ”
                                                </p>
                                                <div class="testimonial_text_img">
                                                    <a href="#"><img src="assets/img/about/customer.png"
                                                                     alt=""></a>
                                                </div>
                                                <div class="testimonial_author">
                                                    <p><a href="#">Rebecka Filson</a> / <span>CEO of CSC</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-testimonial">
                                            <div class="testimonial-icon-img">
                                                <img src="assets/img/about/testimonials-icon.png" alt="">
                                            </div>
                                            <div class="testimonial_content">
                                                <p>“ When a beautiful design is combined with powerful technology,
                                                    <br>
                                                    it truly is an artwork. I love how my website operates and looks
                                                    with this theme. Thank you for the awesome product. ”
                                                </p>
                                                <div class="testimonial_text_img">
                                                    <a href="#"><img src="assets/img/about/testimonial2.png"
                                                                     alt=""></a>
                                                </div>
                                                <div class="testimonial_author">
                                                    <p><a href="#">Amber Laha</a> / <span>CEO of DND</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-testimonial">
                                            <div class="testimonial-icon-img">
                                                <img src="assets/img/about/testimonials-icon.png" alt="">
                                            </div>
                                            <div class="testimonial_content">
                                                <p>“ When a beautiful design is combined with powerful technology,
                                                    <br>
                                                    it truly is an artwork. I love how my website operates and looks
                                                    with this theme. Thank you for the awesome product. ”
                                                </p>
                                                <div class="testimonial_text_img">
                                                    <a href="#"><img src="assets/img/about/testimonial3.png"
                                                                     alt=""></a>
                                                </div>
                                                <div class="testimonial_author">
                                                    <p><a href="#">Lindsy Neloms</a> / <span>CEO of SFD</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--testimonial area end-->
            </div>
        </div>
    </div>
</div>
<!--testimonial area end-->

<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--footer area start-->
<?php include('assets/layouts/footer.php');?>
<!--footer area end-->


<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>