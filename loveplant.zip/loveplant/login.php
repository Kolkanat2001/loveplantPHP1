
<!doctype html>
<?php include('shop/path.php'); ?>
<?php include(ROOT_PATH . "/app/controllers/users.php");
guestsOnly();
?>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>love&Plant - login</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/994.jpg">

    <!-- CSS
    ========================= -->
    <!--bootstrap min css--> <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>

    <!--header area start-->

    <header>
        <div class="main_header">
            <div class="header_top">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-7 col-md-7">
                            <div class="welcome-text">
                                <p>Free Delivery: Take advantage of our time to save event</p>
                            </div>
                        </div>

                        <div class="col-lg-5 col-md-5">
                            <div class="language_currency text-right">
                                <ul>
                                    <li class="currency"><a href="#"> KZT <i class="fa fa-angle-down"></i></a>
                                        <ul class="dropdown_currency">
                                            <li><a href="#">EUR</a></li>
                                            <li><a href="#">USD</a></li>
                                            <li><a href="#">RUP</a></li>
                                        </ul>
                                    </li>
                                    <li class="language"><a href="#"> English <i class="fa fa-angle-down"></i></a>
                                        <ul class="dropdown_language">
                                            <li><a href="#">French</a></li>
                                            <li><a href="#">Spanish</a></li>
                                            <li><a href="#">Russian</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="header_middle">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-3 col-4">
                            <div class="logo">
                                <a href="index.html"><img src="assets/img/logo/logolove.png" alt=""></a>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-6 col-6">
                            <div class="header_right_info">
                                <div class="search_container">
                                    <form action="#">
                                        <div class="hover_category">
                                            <select class="select_option" name="select" id="categori1">
                                                <option selected value="1">All Categories</option>
                                                <option value="2">Plant</option>
                                                <option value="3">Decor</option>
                                                <option value="4">Services</option>
                                            </select>
                                        </div>
                                        <div class="search_box">
                                            <input placeholder="Search product..." type="text">
                                            <button type="submit"><i class="icon-search"></i></button>
                                        </div>
                                    </form>
                                </div>
                                <div class="header_account_area">
                                    <div class="header_account-list top_links">
                                        <a href="#"><i class="icon-users"></i></a>
                                        <ul class="dropdown_links">
                                            <li><a href="checkout.php">Checkout </a></li>
                                            <li><a href="my-account.html">My Account </a></li>
                                            <li><a href="carts.php">Shopping Cart</a></li>
                                            <li><a href="wishlist.php">Wishlist</a></li>
                                        </ul>
                                    </div>
                                    <div class="header_account-list header_wishlist">
                                        <a href="wishlist.php"><i class="icon-heart"></i></a>
                                    </div>
                                    <div class="header_account-list  mini_cart_wrapper"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <a href="javascript:void(0)" id="get-cart" data-toggle="modal"  data-target="#mini-cart" ><i class="icon-shopping-bag"></i><span class="mini-cart-qty item_count" ><?=$_SESSION['cart.qty'] ?? 0 ?></span></a>
                                        <!--mini cart-->

                                        <div class="mini_cart" >
                                            <div class="cart_gallery">
                                                <div class="cart_close">
                                                    <div class="cart_text" >
                                                        <h3 id="exampleModalLabel">cart</h3>
                                                    </div>
                                                    <div class="mini_cart_close">
                                                        <a href="javascript:void(0)"><i class="icon-x"></i></a>
                                                    </div>
                                                </div>
                                                <div class="modal-cart-content">

                                                    <div class="cart_item">
                                                        <?php if (!empty($_SESSION['cart'])): ?>
                                                            <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                                                                <div class="cart_img">

                                                                    <a href="#"><img src="assets/img/product/<?= $item['img'] ?>"
                                                                                     alt="<?= $item['title'] ?>"></a>
                                                                </div>

                                                                <div class="cart_info">
                                                                    <a href="#"><?= $item['title'] ?></a>
                                                                    <p><?= $item['qty'] ?> x <span> <?= $item['price'] ?> </span></p>
                                                                </div>
                                                            <?php endforeach; ?>
                                                            <div class="cart_remove">
                                                                <a href="#"><i class="icon-x"></i></a>
                                                            </div>
                                                        <?php else:?>
                                                            <p>Carts is empty...</p>
                                                        <?php endif;?>
                                                    </div>

                                                    <div class="mini_cart_table">
                                                        <div class="cart_table_border">
                                                            <div class="cart_total">
                                                                <span>Product:</span>
                                                                <span class="price" id="modal-cart-qty"><?=$_SESSION['cart.qty']?></span>
                                                            </div>
                                                            <div class="cart_total mt-10">
                                                                <span>Sum:</span>
                                                                <span class="price"><?=$_SESSION['cart.sum']?></span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="mini_cart_footer">
                                                        <div class="cart_button">
                                                            <div class="cart_button">
                                                                <a href="cart.html"><i class="fa fa-shopping-cart"></i> View cart</a>
                                                                <?php if(!empty($_SESSION['cart'])): ?>
                                                            </div>
                                                            <a class="active" href="checkout.html"><i class="fa fa-sign-in"></i>
                                                                Checkout</a>
                                                        </div>
                                                        <div class="cart_button">
                                                            <button type="button" class="btn btn-danger" id="clear-cart">Clear</button>
                                                        </div>
                                                        <?php endif;?>

                                                    </div>





                                                </div>
                                            </div>
                                        </div>
                                        <!--mini cart end-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="header_bottom sticky-header">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-3">
                            <div class="categories_menu">
                                <div class="categories_title">
                                    <h2 class="categori_toggle">Categories</h2>
                                </div>
                                <div class="categories_menu_toggle">
                                    <ul>
                                        <li class="menu_item_children"><a href="#">Plants <i
                                                        class="fa fa-angle-right"></i></a>
                                            <ul class="categories_mega_menu">
                                                <li class="menu_item_children"><a href="#">Plant</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">home</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">Decor</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Interior</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">Services</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Service</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="menu_item_children"><a href="#"> Decor <i
                                                        class="fa fa-angle-right"></i></a>
                                            <ul class="categories_mega_menu column_3">
                                                <li class="menu_item_children"><a href="#">Interior</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Interior</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">Plant</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Plant</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu_item_children"><a href="#">Services</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Services</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>

                                        <li class="menu_item_children"><a href="#"> Services <i
                                                        class="fa fa-angle-right"></i></a>
                                            <ul class="categories_mega_menu column_2">
                                                <li class="menu_item_children"><a href="#">Services</a>
                                                    <ul class="categorie_sub_menu">
                                                        <li><a href="">Services</a></li>
                                                    </ul>
                                                </li>

                                            </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <!--main menu start-->
                            <div class="main_menu menu_position">
                                <nav>
                                    <ul>
                                        <li><a href="index.php">home<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu">
                                                <li><a href="index.html">Love & Plant Home Page</a></li>

                                                <li><a href="index-3.html">Love & Plant Decoration</a></li>
                                                <li><a href="services.html">Love & Plant Services</a></li>

                                            </ul>
                                        </li>
                                        <li ><a href="shop.php">shop<i></i></a>

                                        </li>

                                        <li><a href="blog.html">blog<i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                                <li><a href="blog-details.html">blog details</a></li>
                                            </ul>
                                        </li>

                                        <li><a class="active" href="#">pages <i class="fa fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                                <li><a href="about.html">About Us</a></li>
                                                <li><a href="services.html">services</a></li>
                                                <li><a href="contact.php">contact</a></li>
                                                <li><a href="login.php">login</a></li>
                                                <li><a href="register.php">Register</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html"> Contact Us</a></li>
                                    </ul>
                                </nav>
                            </div>
                            <!--main menu end-->
                        </div>
                        <div class="col-lg-3">
                            <div class="call-support">
                                <p>Call Support: <a href="tel:87472454517">87472454517</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--header area end-->

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <h3>Login</h3>
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>login</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!-- customer login start -->
    <div class="customer_login">
        <div class="container">
            <div class="row">
                <!--login area start-->
                <div class="col-lg-6 col-md-6">
                    <div class="account_form">

                        <h2>login</h2>
                        <form action="#" class="form-signin" method="POST">
                            <label>Username</label>
                            <input type="text" name="username" value="<?php echo $username; ?>" class="text-input">

                        <label>Password</label>
                        <input type="password" name="password" value="<?php echo $password; ?>" class="text-input">


                            <div class="login_submit">
                                <a href="#">Lost your password?</a>
                                <label for="remember">
                                    <input id="remember" type="checkbox">
                                    Remember me
                                </label>
                                <p>
                                <button  type="submit" name="login-btn">Login</button>
                                </p>

                                <button type="submit"><a  href="register.php" >Registration</a></button>

                            </div>

                        </form>
                    </div>
                </div>
                <!--login area start-->

        </div>
            <?php

            require("connect.php");

            if (isset($_POST['Username']) and isset($_POST['Password'])) {
                $username = $_POST['Username'];
                $password = $_POST['Password'];

                $query = "SELECT * FROM loveplant WHERE username='$username' and password='$password'";
                $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                $count = mysqli_num_rows($result);

                if ($count == 1) {
                    $_SESSION['Username'] = $username;
                } else {
                    $fmsg = "Error";
                }
            }

            if (isset($_SESSION['Username'])) {
                $username = $_SESSION['Username'];
                echo "Hello" . " " . $username . "  <br/>";
                echo "You logged in can now log in our site ";
                echo " " . "<a href='logout.php' class='btn btn-lg btn-primary'>Go to Love&Plant</a>";
            }
            ?>
    </div>

    <!-- customer login end -->
        <!--brand area start-->
        <div class="brand_area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="brand_container owl-carousel">
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                            </div>
                            <div class="single_brand">
                                <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--brand area end-->


        <!--footer area start-->
        <footer class="footer_widgets">
            <div class="footer_top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-4 col-sm-6">
                            <div class="widgets_container contact_us">
                                <h3>Opening Time</h3>
                                <p><span>Mon - Fri:</span> 8AM - 10PM</p>
                                <p><span>Sat:</span> 9AM-8PM</p>
                                <p><span>Suns:</span> 14hPM-18hPM</p>
                                <p><b>We Work All The Holidays</b></p>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-6">
                            <div class="widgets_container widget_menu">
                                <h3>Information</h3>
                                <div class="footer_menu">
                                    <ul>
                                        <li><a href="about.html">About Us</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                        <li><a href="wishlist.php">Wishlist</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-5">
                            <div class="widgets_container widget_app">
                                <div class="footer_logo">
                                    <a href="index.html"><img src="assets/img/logo/logolove.png" alt=""></a>
                                </div>
                                <div class="footer_widgetnav_menu">
                                    <ul>
                                        <li><a href="#">Payment</a></li>
                                        <li><a href="#">Affiliates</a></li>
                                        <li><a href="#">Contact</a></li>
                                        <li><a href="#">Internet</a></li>
                                    </ul>
                                </div>
                                <div class="footer_social">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                        <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                                <div class="footer_app">
                                    <ul>
                                        <li><a href="#"><img src="assets/img/icon/icon-app.jpg" alt=""></a></li>
                                        <li><a href="#"><img src="assets/img/icon/icon1-app.jpg" alt=""></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6">
                            <div class="widgets_container widget_menu">
                                <h3>My Account</h3>
                                <div class="footer_menu">
                                    <ul>
                                        <li><a href="login.php">My Account</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                        <li><a href="carts.php">Shopping cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="shop.php">Shop</a></li>
                                        <li><a href="#">Order History</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-6">
                            <div class="widgets_container widget_menu">
                                <h3>Customer Service</h3>
                                <div class="footer_menu">
                                    <ul>
                                        <li><a href="contact.html">Contact Us</a></li>
                                        <li><a href="#">Terms of use</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="contact.php">Site Map</a></li>
                                        <li><a href="login.php">Login</a></li>
                                        <li><a href="#">Returns</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer_bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="copyright_area">
                                <p class="copyright-text">&copy; 2022. <a href="index.php">Love & Plant</a> </p>

                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="footer_payment">
                                <a href="#"><img src="assets/img/icon/payment.png" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--footer area end-->

    <!-- JS
============================================ -->
    <!--jquery min js-->
    <script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
    <!--popper min js-->
    <script src="assets/js/popper.js"></script>
    <!--bootstrap min js-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--owl carousel min js-->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!--slick min js-->
    <script src="assets/js/slick.min.js"></script>
    <!--magnific popup min js-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!--counterup min js-->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!--jquery countdown min js-->
    <script src="assets/js/jquery.countdown.js"></script>
    <!--jquery ui min js-->
    <script src="assets/js/jquery.ui.js"></script>
    <!--jquery elevatezoom min js-->
    <script src="assets/js/jquery.elevatezoom.js"></script>
    <!--isotope packaged min js-->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--slinky menu js-->
    <script src="assets/js/slinky.menu.js"></script>
    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>

</html>