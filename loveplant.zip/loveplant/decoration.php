<?php session_start();?>


<?php
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/func.php';
$products = get_products();

include("shop/path.php");

include (ROOT_PATH . "/app/controllers/topics.php");
$posts = array();
$postsTitle = 'Recent Posts';

if (isset($_GET['t_id'])) {
    $posts = getPostsByTopicId($_GET['t_id']);
    $postsTitle = "You searched for posts under '" . $_GET['name'] . "'";
}
else {
    $posts = getPublishedPosts();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Love & Plant – Plant and Flower Shop eCommerce </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/jpg" href="assets/img/994.jpg"/>

    <!-- CSS
    ========================= -->
    <!--bootstrap min css-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--owl carousel min css-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--slick min css-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--magnific popup min css-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--font awesome css-->
    <link rel="stylesheet" href="assets/css/font.awesome.css">
    <!--animate css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--jquery ui min css-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--slinky menu css-->
    <link rel="stylesheet" href="assets/css/slinky.menu.css">
    <!--plugins css-->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<!--header area start-->
<?php include('assets/layouts/header.php');?>
<!--header area end-->

<!--slider area start-->
<section class="slider_section slider_s_two">
    <div class="slider_area owl-carousel">
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider7.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <span>AMAZING FROM Love & Plant </span>
                            <h1>Decoration <br> For Your Home</h1>
                            <p>Decorating your home with our collection of green friends </p>
                            <a class="button" href="shop-fullwidth.html">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider8.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <span>AMAZING FROM Love & Plant </span>
                            <h1>Decoration <br> <span>for Organizations</span></h1>
                            <p>We organize beautifully the event and the room with our plants </p>
                            <a class="button" href="shop-fullwidth.html">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/slider9.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="slider_content">
                            <span>AMAZING FROM Love & Plant </span>
                            <h1>Green office <br> <span>Decoration</span></h1>
                            <p>Together with you we will develop a green office concept </p>
                            <a class="button" href="shop-fullwidth.html">Discover Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--slider area end-->

<!--Love & Plant store title start-->
<div class="welcome_Love & Plant_store">
    <div class="container">
        <div class="welcome_Love & Plant_container">
            <div class="row">
                <div class="col-lg-5 col-md-5">
                    <div class="welcome_Love & Plant_thumb">
                        <img src="assets/img/bg/img-top-vogue3.png" alt="">
                    </div>
                </div>
                <div class="col-lg-7 col-md-7">
                    <div class="welcome_Love & Plant_content">
                        <div class="welcome_Love & Plant_header">
                            <h3> </h3>
                            <h2>Love & Plant Decoration</h2>
                        </div>
                        <div class="welcome_Love & Plant_desc">
                            <p>Even if your home is lacking in square footage, incorporating some
                                greenery here and there is essential to bringing it to life.</p>
                            <p>Naturally, indoor plants add more beauty to a space while also providing functional benefits,
                                like promoting a positive mood, purifying the air, and making you
                                feel connected to nature without having to step outside
                                Our company will help and give you advice in decorating with plants.</p>
                        </div>
                        <div class="welcome_Love & Plant_footer">
                            <img src="assets/img/bg/signature.png" alt="">
                            <p><span>john doe</span> – CEO Love & Plant</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Love & Plant store titlev end-->

<!--product area start-->
<div class="product_area product_style2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Popular products in decorations</h2>
                </div>
            </div>
        </div>
        <div class="product_style2_ocntainer">
            <div class="row">
                <div class="product_carousel product2_column5 owl-carousel">
                    <?php
                    include ('inc/db.php');

                    $query=$pdo->prepare("select *from love_plant.products LIMIT 0,6");
                    $query->execute();

                    while($row=$query->fetch()):?>

                        <div class="col-lg-3">
                        <div class="product_items">

                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="product-details.php?page=detail&id=<?= $row['id']?>"><img
                                                    src="assets/img/product/<?= $row['img']?>" alt=""></a>
                                            <div class="label_product">
                                                <span class="label_sale">-7%</span>
                                            </div>

                                        </div>
                                        <figcaption class="product_content">

                                            <h4 class="product_name"><a href="product-details.php?page=detail&id=<?= $row['id']?>"><?= $row['title']?></a></h4>
                                            <div class="price_box">
                                                <span class="current_price"><?= $row['price']?>₸</span>
                                                <span class="old_price"><?= $row['old_price']?>₸</span>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </article>

                        </div>
                    </div>
                    <?php endwhile;?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--product area end-->

<!--testimonial area start-->
<div class="testimonial_area testimonial_two">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>What Our Customers Says ?</h2>
                </div>
            </div>
        </div>
        <div class="testimonial_container">
            <div class="row">
                <div class="testimonial_carousel owl-carousel">
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ When a beautiful design is combined with powerful technology, <br>
                                    it truly is an artwork. I love how my organization and looks with this
                                    plants. Thank you for the awesome decoration. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/decorhome.jpg" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Rebecka Filson</a> / <span>Director of WOK</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ Having plants in the office has been shown to improve air quality,
                                    increase attention span, improve creativity, lower stress and stabilise mood.
                                    Most people spend a large part of their lifespan in offices.
                                    So I am glad that Love & Plant help to solve this problem. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/greenoffice.jpg" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Amber Laha</a> / <span>CEO of DND</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="single-testimonial">
                            <div class="testimonial-icon-img">
                                <img src="assets/img/about/testimonials-icon.png" alt="">
                            </div>
                            <div class="testimonial_content">
                                <p>“ I love how my interior with house plants looks now. Thank you Love & Plants for this!
                                    When a beautiful design is combined with powerful technology, <br>
                                    it truly is an artwork. I love how my website operates and looks with this
                                    theme. Thank you for the awesome product. ”</p>
                                <div class="testimonial_text_img">
                                    <a href="#"><img src="assets/img/about/greenoffice4.jpg" alt=""></a>
                                </div>
                                <div class="testimonial_author">
                                    <p><a href="#">Lindsy Neloms</a> / <span>CEO of SFD</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--testimonial area end-->

<!--brand area start-->
<div class="brand_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="brand_container owl-carousel">
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand1.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand3.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand4.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand5.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand6.png" alt=""></a>
                    </div>
                    <div class="single_brand">
                        <a href="#"><img src="assets/img/brand/brand2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--brand area end-->

<!--blog area start-->
<section class="blog_section blog_s_three">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Our Latest Posts</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="blog_carousel blog_column3 owl-carousel">
                <?php foreach ($posts as $post): ?>
                    <div class="col-lg-3">
                        <article class="single_blog">
                            <figure>
                                <div class="blog_thumb">
                                    <a href="blog-details.php?id=<?php echo $post['id']; ?>"><img src="assets/img/blog/<?php echo $post['image']; ?>" alt=""></a>
                                </div>
                                <figcaption class="blog_content">
                                    <h4 class="post_title"><a href="blog-details.php?id=<?php echo $post['id']; ?>"><?php echo $post['title']; ?></a></h4>
                                    <div class="articles_date">
                                        <p>By <span><?php echo $post['username']; ?> / <?php echo date('F j, Y', strtotime($post['created_at'])); ?></span></p>
                                    </div>
                                    <p class="post_desc"><?php echo html_entity_decode(substr($post['body'], 0, 150) . '...'); ?></p>
                                    <footer class="blog_footer">
                                        <a href="blog-details.php?id=<?php echo $post['id']; ?>">Continue Reading</a>
                                        <p><i class="icon-message-circle"></i> <span>0</span></p>
                                    </footer>
                                </figcaption>
                            </figure>
                        </article>
                    </div>
                <?php endforeach;?>
            </div>
        </div>
    </div>
</section>
<!--blog area end-->

<!--newsletter area start-->
<div class="newsletter_area_start newsletter_two">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section_title">
                    <h2>Get <span>20% Off</span> Your Next Order</h2>
                </div>
                <div class="newsletter_container">
                    <div class="subscribe_form">
                        <form id="mc-form" class="mc-form footer-newsletter">
                            <input id="mc-email" type="email" autocomplete="off" placeholder="Enter you email" />
                            <button id="mc-submit">Subscribe</button>
                            <div class="email_icon">
                                <i class="icon-mail"></i>
                            </div>
                        </form>
                        <!-- mailchimp-alerts Start -->
                        <div class="mailchimp-alerts text-centre">
                            <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                            <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                            <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                        </div><!-- mailchimp-alerts end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--newsletter area end-->

<!--footer area start-->
<?php include('assets/layouts/footer.php');?>
<!--footer area end-->



<!-- JS
============================================ -->
<!--jquery min js-->
<script src="assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--counterup min js-->
<script src="assets/js/jquery.counterup.min.js"></script>
<!--jquery countdown min js-->
<script src="assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!--slinky menu js-->
<script src="assets/js/slinky.menu.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>